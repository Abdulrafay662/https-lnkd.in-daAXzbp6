/*
# Add delete_user_account RPC

1. New Functions
- `delete_user_account()` — SECURITY DEFINER function that deletes the calling user's auth account.
  This is needed because the anon/authenticated role cannot directly call `auth.admin.deleteUser()`.
  The function uses `auth.uid()` to identify the caller, so only the authenticated user can delete their own account.
2. Security
- SECURITY DEFINER so it can access the auth admin API.
- search_path set to 'auth' to access auth schema.
- Only deletes the calling user — no parameters accepted.
*/

CREATE OR REPLACE FUNCTION public.delete_user_account()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO auth, public
AS $$
DECLARE
  current_user_id uuid;
BEGIN
  current_user_id := auth.uid();
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  -- Cascade deletes all user data via FK ON DELETE CASCADE
  PERFORM auth.admin.delete_user(current_user_id);
END;
$$;

GRANT EXECUTE ON FUNCTION public.delete_user_account() TO authenticated;
