import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");

const MODEL = "gpt-4o-mini";

interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

async function callOpenAI(messages: ChatMessage[]): Promise<string> {
  if (!OPENAI_API_KEY) {
    throw new Error("AI_API_NOT_CONFIGURED");
  }

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      temperature: 0.7,
      max_tokens: 2000,
    }),
  });

  if (!response.ok) {
    if (response.status === 429) throw new Error("RATE_LIMITED");
    throw new Error(`OpenAI error: ${response.status}`);
  }

  const data = await response.json();
  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error("EMPTY_RESPONSE");
  return content;
}

function buildContextBlock(context: {
  goals?: { title: string; status: string; category: string }[];
  tasks?: { title: string; status: string; priority: string }[];
  habits?: { name: string; frequency: string; logs: string[] }[];
}): string {
  const parts: string[] = [];

  if (context.goals && context.goals.length > 0) {
    parts.push("GOALS:");
    context.goals.forEach((g) => {
      parts.push(`- ${g.title} [${g.category}] — Status: ${g.status}`);
    });
  } else {
    parts.push("GOALS: None");
  }

  if (context.tasks && context.tasks.length > 0) {
    parts.push("\nTASKS:");
    context.tasks.forEach((t) => {
      parts.push(`- ${t.title} [Priority: ${t.priority}] — Status: ${t.status}`);
    });
  } else {
    parts.push("\nTASKS: None");
  }

  if (context.habits && context.habits.length > 0) {
    parts.push("\nHABITS:");
    context.habits.forEach((h) => {
      parts.push(`- ${h.name} [${h.frequency}] — Completed on: ${h.logs.length > 0 ? h.logs.join(", ") : "never"}`);
    });
  } else {
    parts.push("\nHABITS: None");
  }

  return parts.join("\n");
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const action = body.action;

    let systemPrompt = "";
    let userPrompt = "";
    let messages: ChatMessage[] = [];

    switch (action) {
      case "plan": {
        const input = body.input;
        systemPrompt = "You are LifeOS AI, a productivity planning assistant. Create structured, actionable plans based on the user's goal, available time, and constraints. Format your response in clear markdown with sections for: Overall Objective, Weekly Milestones, Daily Tasks, Estimated Duration, Priority, and Recommended Order. Be specific and practical. Do not invent information not provided.";
        userPrompt = `Create a plan for:\n\nGoal: ${input.goal}\nAvailable hours: ${input.hours}\nDeadline: ${input.deadline}\nCurrent progress: ${input.progress}\nImportant tasks: ${input.tasks}\nConstraints: ${input.constraints}`;
        messages = [{ role: "system", content: systemPrompt }, { role: "user", content: userPrompt }];
        break;
      }

      case "breakdown": {
        const input = body.input;
        systemPrompt = "You are LifeOS AI. Break down the given goal into smaller, actionable tasks. Return ONLY a numbered list of tasks, each on its own line, concise and actionable. Do not include any other text or explanation.";
        userPrompt = `Break down this goal into actionable tasks:\n\nGoal: ${input.goalTitle}\n${input.goalDescription ? `Description: ${input.goalDescription}` : ""}`;
        messages = [{ role: "system", content: systemPrompt }, { role: "user", content: userPrompt }];
        break;
      }

      case "review": {
        const input = body.input;
        const contextBlock = buildContextBlock(input);
        systemPrompt = "You are LifeOS AI. Analyze the user's actual productivity data and generate a weekly review. Use ONLY the data provided — never invent activity, statistics, or progress. If data is missing, say so explicitly. Format your response in markdown with these sections: ## Weekly Summary, ## Progress, ## Problems, ## Recommendations, ## Next Week Focus (list 3 priorities).";
        userPrompt = `Analyze this week's data and generate a weekly review:\n\n${contextBlock}`;
        messages = [{ role: "system", content: systemPrompt }, { role: "user", content: userPrompt }];
        break;
      }

      case "assistant": {
        const history = body.history || [];
        const context = body.context || {};
        const contextBlock = buildContextBlock(context);
        systemPrompt = `You are LifeOS AI, a personal productivity assistant. You help the user based on their actual LifeOS data. Use ONLY the data provided below — never invent progress, statistics, or activity. If information is missing, clearly say you don't have that information. Be concise and helpful.\n\nUSER'S LIFEOS DATA:\n${contextBlock}`;
        messages = [{ role: "system", content: systemPrompt }];
        for (const m of history) {
          messages.push({ role: m.role, content: m.content });
        }
        break;
      }

      default:
        return new Response(JSON.stringify({ error: "Invalid action" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }

    const content = await callOpenAI(messages);
    return new Response(JSON.stringify({ content }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    let status = 500;
    let userMsg = "AI is temporarily unavailable. Please try again.";

    if (msg === "AI_API_NOT_CONFIGURED") {
      status = 503;
      userMsg = "AI is not configured yet. The AI API key needs to be set up. Please try again later.";
    } else if (msg === "RATE_LIMITED") {
      status = 429;
      userMsg = "AI is currently busy. Please try again in a moment.";
    } else if (msg === "EMPTY_RESPONSE") {
      userMsg = "AI returned an empty response. Please try again.";
    }

    return new Response(JSON.stringify({ error: userMsg }), {
      status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
