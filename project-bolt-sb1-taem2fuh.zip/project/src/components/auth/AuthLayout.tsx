import { type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Brain, TrendingUp, Target, CheckSquare } from 'lucide-react';
import { Logo } from '@/components/Logo';

export function AuthLayout({ children, title, subtitle }: { children: ReactNode; title: string; subtitle: string }) {
  return (
    <div className="min-h-screen flex">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-brand-700 to-brand-900 p-12 flex-col justify-between relative overflow-hidden">
        <div className="absolute top-20 right-20 w-72 h-72 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-60 h-60 bg-brand-400/20 rounded-full blur-3xl" />
        <Link to="/" className="relative">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
              <Brain size={20} className="text-white" />
            </div>
            <span className="text-lg font-bold text-white">LifeOS<span className="text-brand-300"> AI</span></span>
          </div>
        </Link>
        <div className="relative">
          <h2 className="text-3xl font-bold text-white mb-4 leading-tight">Your Life.<br />Organized by AI.</h2>
          <p className="text-brand-100 mb-8 max-w-md">Turn your goals, tasks, and habits into an intelligent plan that helps you make consistent progress.</p>
          <div className="space-y-3">
            {[
              { icon: Target, text: 'AI-powered goal planning and task breakdown' },
              { icon: CheckSquare, text: 'Smart daily planning with priorities' },
              { icon: TrendingUp, text: 'Weekly reviews and progress insights' },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} className="flex items-center gap-3 text-brand-100">
                  <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                    <Icon size={16} />
                  </div>
                  <span className="text-sm">{item.text}</span>
                </div>
              );
            })}
          </div>
        </div>
        <p className="relative text-xs text-brand-200">LifeOS AI — Your Life, Organized by AI.</p>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-6 bg-slate-50 dark:bg-slate-950">
        <div className="w-full max-w-sm">
          <div className="lg:hidden mb-8 flex justify-center">
            <Link to="/"><Logo size="md" /></Link>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-1.5">{title}</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">{subtitle}</p>
          {children}
        </div>
      </div>
    </div>
  );
}
