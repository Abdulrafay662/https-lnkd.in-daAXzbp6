import { useState, useEffect } from 'react';
import { Outlet, NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Target, CheckSquare, Repeat, CalendarDays,
  TrendingUp, Bot, Settings, Menu, X, Moon, Sun, Bell, Search, LogOut,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { Logo } from '@/components/Logo';
import { Avatar } from '@/components/Avatar';
import { supabase } from '@/lib/supabase';
import type { Notification } from '@/types';

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/dashboard/goals', label: 'Goals', icon: Target },
  { to: '/dashboard/tasks', label: 'Tasks', icon: CheckSquare },
  { to: '/dashboard/habits', label: 'Habits', icon: Repeat },
  { to: '/dashboard/planner', label: 'AI Planner', icon: CalendarDays },
  { to: '/dashboard/progress', label: 'Progress', icon: TrendingUp },
  { to: '/dashboard/assistant', label: 'AI Assistant', icon: Bot },
  { to: '/dashboard/settings', label: 'Settings', icon: Settings },
];

const pageTitles: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/dashboard/goals': 'Goals',
  '/dashboard/tasks': 'Tasks',
  '/dashboard/habits': 'Habits',
  '/dashboard/planner': 'AI Planner',
  '/dashboard/progress': 'Progress',
  '/dashboard/assistant': 'AI Assistant',
  '/dashboard/settings': 'Settings',
};

export function DashboardLayout() {
  const { user, profile, signOut } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const title = pageTitles[location.pathname] || 'Dashboard';

  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(20)
      .then(({ data }) => setNotifications((data as Notification[]) || []));
  }, [user]);

  const unreadCount = notifications.filter((n) => !n.read).length;

  async function markAllRead() {
    if (!user) return;
    await supabase.from('notifications').update({ read: true }).eq('user_id', user.id).eq('read', false);
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }

  async function clearNotification(id: string) {
    await supabase.from('notifications').delete().eq('id', id);
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }

  async function handleSignOut() {
    await signOut();
    navigate('/');
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 left-0 z-40 h-screen w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-5 border-b border-slate-200 dark:border-slate-800">
          <NavLink to="/dashboard">
            <Logo size="md" />
          </NavLink>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/dashboard'}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-brand-50 dark:bg-brand-950/50 text-brand-700 dark:text-brand-400'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`
                }
              >
                <Icon size={18} />
                {item.label}
              </NavLink>
            );
          })}
        </nav>
        <div className="p-3 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={handleSignOut}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors w-full"
          >
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between px-4 lg:px-6 h-16">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                aria-label="Open menu"
              >
                <Menu size={20} />
              </button>
              <h1 className="text-lg font-semibold text-slate-900 dark:text-white">{title}</h1>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                onClick={() => setSearchOpen(true)}
                className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                aria-label="Search"
              >
                <Search size={20} />
              </button>

              <div className="relative">
                <button
                  onClick={() => setNotifOpen(!notifOpen)}
                  className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative"
                  aria-label="Notifications"
                >
                  <Bell size={20} />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-brand-500 text-white text-[10px] font-bold flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </button>
                {notifOpen && (
                  <>
                    <div className="fixed inset-0 z-30" onClick={() => setNotifOpen(false)} />
                    <div className="absolute right-0 mt-2 w-80 max-w-[calc(100vw-2rem)] card shadow-lg z-40 animate-scale-in">
                      <div className="flex items-center justify-between p-3 border-b border-slate-200 dark:border-slate-800">
                        <span className="font-semibold text-sm text-slate-900 dark:text-white">Notifications</span>
                        {unreadCount > 0 && (
                          <button onClick={markAllRead} className="text-xs text-brand-600 dark:text-brand-400 hover:underline">
                            Mark all read
                          </button>
                        )}
                      </div>
                      <div className="max-h-80 overflow-y-auto">
                        {notifications.length === 0 ? (
                          <div className="p-6 text-center text-sm text-slate-500 dark:text-slate-400">No notifications</div>
                        ) : (
                          notifications.map((n) => (
                            <div key={n.id} className="flex items-start gap-2 p-3 border-b border-slate-100 dark:border-slate-800 last:border-0">
                              <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${n.read ? 'bg-slate-300 dark:bg-slate-700' : 'bg-brand-500'}`} />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-slate-900 dark:text-white">{n.title}</p>
                                {n.message && <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{n.message}</p>}
                              </div>
                              <button onClick={() => clearNotification(n.id)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 shrink-0" aria-label="Clear notification">
                                <X size={14} />
                              </button>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>

              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                aria-label="Toggle theme"
              >
                {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
              </button>

              <NavLink to="/dashboard/settings" className="ml-1">
                <Avatar name={profile?.full_name} url={profile?.avatar_url} size="sm" />
              </NavLink>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">
          <Outlet />
        </main>
      </div>

      {searchOpen && <SearchModal onClose={() => setSearchOpen(false)} />}
    </div>
  );
}

function SearchModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<{ goals: { id: string; title: string }[]; tasks: { id: string; title: string }[]; habits: { id: string; name: string }[] }>({ goals: [], tasks: [], habits: [] });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  useEffect(() => {
    if (!user || query.trim().length < 2) {
      setResults({ goals: [], tasks: [], habits: [] });
      return;
    }
    setLoading(true);
    const timer = setTimeout(async () => {
      const [goalsRes, tasksRes, habitsRes] = await Promise.all([
        supabase.from('goals').select('id, title').eq('user_id', user.id).ilike('title', `%${query}%`).limit(5),
        supabase.from('tasks').select('id, title').eq('user_id', user.id).ilike('title', `%${query}%`).limit(5),
        supabase.from('habits').select('id, name').eq('user_id', user.id).ilike('name', `%${query}%`).limit(5),
      ]);
      setResults({
        goals: (goalsRes.data as { id: string; title: string }[]) || [],
        tasks: (tasksRes.data as { id: string; title: string }[]) || [],
        habits: (habitsRes.data as { id: string; name: string }[]) || [],
      });
      setLoading(false);
    }, 200);
    return () => clearTimeout(timer);
  }, [query, user]);

  const hasResults = results.goals.length > 0 || results.tasks.length > 0 || results.habits.length > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 animate-fade-in-fast" role="dialog" aria-modal="true" aria-label="Search">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-xl card shadow-xl animate-scale-in">
        <div className="flex items-center gap-3 p-4 border-b border-slate-200 dark:border-slate-800">
          <Search size={20} className="text-slate-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search goals, tasks, habits..."
            className="flex-1 bg-transparent outline-none text-slate-900 dark:text-white placeholder-slate-400"
            autoFocus
            aria-label="Search query"
          />
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200" aria-label="Close search">
            <X size={20} />
          </button>
        </div>
        <div className="max-h-80 overflow-y-auto">
          {loading && <div className="p-6 text-center text-sm text-slate-500 dark:text-slate-400">Searching...</div>}
          {!loading && !hasResults && query.trim().length >= 2 && (
            <div className="p-6 text-center text-sm text-slate-500 dark:text-slate-400">No results found</div>
          )}
          {!loading && query.trim().length < 2 && (
            <div className="p-6 text-center text-sm text-slate-500 dark:text-slate-400">Type at least 2 characters to search</div>
          )}
          {!loading && hasResults && (
            <div className="p-2">
              {results.goals.length > 0 && (
                <div>
                  <p className="px-3 py-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">Goals</p>
                  {results.goals.map((g) => (
                    <NavLink key={g.id} to="/dashboard/goals" onClick={onClose} className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sm text-slate-700 dark:text-slate-300">
                      <Target size={16} className="text-brand-500" /> {g.title}
                    </NavLink>
                  ))}
                </div>
              )}
              {results.tasks.length > 0 && (
                <div>
                  <p className="px-3 py-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">Tasks</p>
                  {results.tasks.map((t) => (
                    <NavLink key={t.id} to="/dashboard/tasks" onClick={onClose} className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sm text-slate-700 dark:text-slate-300">
                      <CheckSquare size={16} className="text-brand-500" /> {t.title}
                    </NavLink>
                  ))}
                </div>
              )}
              {results.habits.length > 0 && (
                <div>
                  <p className="px-3 py-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">Habits</p>
                  {results.habits.map((h) => (
                    <NavLink key={h.id} to="/dashboard/habits" onClick={onClose} className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sm text-slate-700 dark:text-slate-300">
                      <Repeat size={16} className="text-brand-500" /> {h.name}
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
