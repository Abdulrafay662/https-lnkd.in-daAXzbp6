import { getInitials } from '@/lib/utils';

interface AvatarProps {
  name: string | null;
  url: string | null;
  size?: 'sm' | 'md' | 'lg';
}

export function Avatar({ name, url, size = 'md' }: AvatarProps) {
  const sizes = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-16 h-16 text-xl',
  };

  if (url) {
    return (
      <img
        src={url}
        alt={name || 'Profile'}
        className={`${sizes[size]} rounded-full object-cover ring-2 ring-slate-200 dark:ring-slate-700`}
      />
    );
  }

  return (
    <div className={`${sizes[size]} rounded-full bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center font-semibold text-white ring-2 ring-slate-200 dark:ring-slate-700`}>
      {getInitials(name)}
    </div>
  );
}
