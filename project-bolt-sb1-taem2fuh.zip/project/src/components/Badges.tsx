import { type LucideIcon, CheckCircle2, Clock, AlertCircle, Circle } from 'lucide-react';
import type { Priority } from '@/types';

export function PriorityBadge({ priority }: { priority: Priority }) {
  const config: Record<Priority, { color: string; icon: LucideIcon }> = {
    High: { color: 'bg-red-100 text-red-700 dark:bg-red-950/50 dark:text-red-400', icon: AlertCircle },
    Medium: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-950/50 dark:text-amber-400', icon: Clock },
    Low: { color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400', icon: Circle },
  };
  const { color, icon: Icon } = config[priority];
  return (
    <span className={`badge ${color}`}>
      <Icon size={12} />
      {priority}
    </span>
  );
}

export function StatusBadge({ status }: { status: string }) {
  if (status === 'completed') {
    return (
      <span className="badge bg-emerald-100 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400">
        <CheckCircle2 size={12} />
        Completed
      </span>
    );
  }
  return (
    <span className="badge bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300">
      <Clock size={12} />
      Active
    </span>
  );
}
