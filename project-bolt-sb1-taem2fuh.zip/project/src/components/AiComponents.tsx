import { type ReactNode } from 'react';
import { type LucideIcon, Sparkles } from 'lucide-react';

export function ThinkingIndicator({ message = 'LifeOS AI is thinking...' }: { message?: string }) {
  return (
    <div className="flex items-center gap-3 text-slate-500 dark:text-slate-400 animate-fade-in">
      <div className="w-8 h-8 rounded-lg bg-brand-50 dark:bg-brand-950/50 flex items-center justify-center">
        <Sparkles size={16} className="text-brand-500 animate-pulse-soft" />
      </div>
      <div className="flex flex-col gap-1">
        <span className="text-sm font-medium">{message}</span>
        <div className="flex gap-1">
          <span className="typing-dot text-brand-400" />
          <span className="typing-dot text-brand-400" />
          <span className="typing-dot text-brand-400" />
        </div>
      </div>
    </div>
  );
}

export function ErrorBanner({ message }: { message: string }) {
  return (
    <div className="flex items-start gap-3 p-4 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 animate-fade-in">
      <span className="text-sm">{message}</span>
    </div>
  );
}

export function AiResponseDisplay({ content }: { content: string }) {
  const sections = content.split(/^## /m).filter(Boolean);
  return (
    <div className="prose prose-sm dark:prose-invert max-w-none animate-fade-in">
      {sections.map((section, i) => {
        const lines = section.split('\n');
        const heading = lines[0].trim();
        const body = lines.slice(1).join('\n').trim();
        return (
          <div key={i} className="mb-4">
            {heading && <h3 className="font-semibold text-slate-900 dark:text-white mb-1.5">{heading}</h3>}
            <div className="text-sm text-slate-600 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">{body}</div>
          </div>
        );
      })}
    </div>
  );
}

export function SectionCard({ icon: Icon, title, children }: { icon: LucideIcon; title: string; children: ReactNode }) {
  return (
    <div className="card p-5">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-8 h-8 rounded-lg bg-brand-50 dark:bg-brand-950/50 flex items-center justify-center">
          <Icon size={16} className="text-brand-500" />
        </div>
        <h3 className="font-semibold text-slate-900 dark:text-white">{title}</h3>
      </div>
      {children}
    </div>
  );
}
