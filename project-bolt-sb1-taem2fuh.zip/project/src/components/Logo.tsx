import { Brain } from 'lucide-react';

export function Logo({ size = 'md', showText = true }: { size?: 'sm' | 'md' | 'lg'; showText?: boolean }) {
  const sizes = {
    sm: { box: 'w-7 h-7', icon: 16, text: 'text-base' },
    md: { box: 'w-9 h-9', icon: 20, text: 'text-lg' },
    lg: { box: 'w-12 h-12', icon: 28, text: 'text-2xl' },
  };
  const s = sizes[size];
  return (
    <div className="flex items-center gap-2.5">
      <div className={`${s.box} rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center shadow-sm shadow-brand-600/30` as string}>
        <Brain size={s.icon} className="text-white" />
      </div>
      {showText && (
        <span className={`${s.text} font-bold tracking-tight text-slate-900 dark:text-white`}>
          LifeOS<span className="text-brand-500"> AI</span>
        </span>
      )}
    </div>
  );
}
