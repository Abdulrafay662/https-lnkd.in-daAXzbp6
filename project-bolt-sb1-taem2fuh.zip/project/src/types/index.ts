export type GoalCategory = 'Career' | 'Education' | 'Health' | 'Personal' | 'Finance' | 'Projects' | 'Other';
export type Priority = 'Low' | 'Medium' | 'High';
export type GoalStatus = 'active' | 'completed';
export type TaskStatus = 'pending' | 'completed';
export type HabitFrequency = 'Daily' | 'Weekly';

export const GOAL_CATEGORIES: GoalCategory[] = ['Career', 'Education', 'Health', 'Personal', 'Finance', 'Projects', 'Other'];
export const PRIORITIES: Priority[] = ['Low', 'Medium', 'High'];
export const HABIT_FREQUENCIES: HabitFrequency[] = ['Daily', 'Weekly'];

export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  description: string | null;
  main_focus: string | null;
  time_zone: string | null;
  onboarding_completed: boolean;
  onboarding_focus: string | null;
  onboarding_goal: string | null;
  onboarding_daily_time: string | null;
  created_at: string;
  updated_at: string;
}

export interface Goal {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  category: GoalCategory;
  priority: Priority;
  target_date: string | null;
  status: GoalStatus;
  created_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  goal_id: string | null;
  priority: Priority;
  due_date: string | null;
  status: TaskStatus;
  created_at: string;
  goals?: { title: string } | null;
}

export interface Habit {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  frequency: HabitFrequency;
  created_at: string;
}

export interface HabitLog {
  id: string;
  user_id: string;
  habit_id: string;
  completed_date: string;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  message: string | null;
  read: boolean;
  created_at: string;
}

export interface DailyPlan {
  id: string;
  user_id: string;
  plan_date: string;
  plan_content: Record<string, unknown> | null;
  created_at: string;
}

export interface AiUsage {
  id: string;
  user_id: string;
  usage_date: string;
  request_count: number;
}
