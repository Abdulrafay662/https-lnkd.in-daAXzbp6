import { supabase } from './supabase';
import { checkAiUsage, incrementAiUsage } from './ai-usage';

export interface AiPlanInput {
  goal: string;
  hours: string;
  deadline: string;
  progress: string;
  tasks: string;
  constraints: string;
}

export interface AiChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface AiBreakdownInput {
  goalTitle: string;
  goalDescription?: string;
}

export interface AiReviewInput {
  goals: { title: string; status: string; category: string }[];
  tasks: { title: string; status: string; priority: string }[];
  habits: { name: string; frequency: string; logs: string[] }[];
}

async function callAiFunction(action: string, payload: Record<string, unknown>): Promise<string> {
  const { data: usageData, error: usageError } = await supabase.auth.getUser();
  const user = usageData.user;
  if (!user) throw new Error('You must be signed in to use AI features.');

  const usage = await checkAiUsage(user.id);
  if (!usage.allowed) {
    throw new Error("You've reached today's AI usage limit. Please try again tomorrow.");
  }

  const { data: sessionData } = await supabase.auth.getSession();
  const token = sessionData.session?.access_token;
  if (!token) throw new Error('Authentication required.');

  const functionUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-service`;

  let response: Response;
  try {
    response = await fetch(functionUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
      },
      body: JSON.stringify({ action, ...payload }),
    });
  } catch {
    throw new Error('Network error. Please check your connection and try again.');
  }

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    if (response.status === 429) {
      throw new Error("You've reached today's AI usage limit. Please try again tomorrow.");
    }
    if (response.status === 503) {
      throw new Error('AI is temporarily unavailable. Please try again later.');
    }
    throw new Error(body?.error || 'AI is temporarily unavailable. Please try again.');
  }

  const body = await response.json().catch(() => ({}));
  if (!body.content) {
    throw new Error('AI returned an empty response. Please try again.');
  }

  await incrementAiUsage(user.id);
  return body.content as string;
}

export async function generateAiPlan(input: AiPlanInput): Promise<string> {
  return callAiFunction('plan', { input });
}

export async function generateAiBreakdown(input: AiBreakdownInput): Promise<string> {
  return callAiFunction('breakdown', { input });
}

export async function generateAiReview(input: AiReviewInput): Promise<string> {
  return callAiFunction('review', { input });
}

export async function generateAiAssistantReply(history: AiChatMessage[], context: AiReviewInput): Promise<string> {
  return callAiFunction('assistant', { history, context });
}
