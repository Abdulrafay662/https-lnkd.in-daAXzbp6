import { supabase } from './supabase';
import type { AiUsage } from '@/types';

const DAILY_AI_LIMIT = 30;

export async function checkAiUsage(userId: string): Promise<{ allowed: boolean; remaining: number }> {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase
    .from('ai_usage')
    .select('request_count')
    .eq('user_id', userId)
    .eq('usage_date', today)
    .maybeSingle();

  const count = (data as AiUsage | null)?.request_count ?? 0;
  return { allowed: count < DAILY_AI_LIMIT, remaining: Math.max(0, DAILY_AI_LIMIT - count) };
}

export async function incrementAiUsage(userId: string): Promise<void> {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase
    .from('ai_usage')
    .select('id, request_count')
    .eq('user_id', userId)
    .eq('usage_date', today)
    .maybeSingle();

  if (data) {
    await supabase
      .from('ai_usage')
      .update({ request_count: (data as AiUsage).request_count + 1 })
      .eq('id', (data as AiUsage).id);
  } else {
    await supabase
      .from('ai_usage')
      .insert({ user_id: userId, usage_date: today, request_count: 1 });
  }
}

export const AI_LIMIT = DAILY_AI_LIMIT;
