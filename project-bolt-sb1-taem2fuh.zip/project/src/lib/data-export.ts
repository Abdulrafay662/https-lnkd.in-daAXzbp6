import { supabase } from './supabase';
import type { Goal, Task, Habit, HabitLog, Profile } from '@/types';

export interface ExportData {
  profile: Profile | null;
  goals: Goal[];
  tasks: Task[];
  habits: Habit[];
  habit_logs: HabitLog[];
  exported_at: string;
}

export async function exportUserData(userId: string): Promise<ExportData> {
  const [profileRes, goalsRes, tasksRes, habitsRes, logsRes] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', userId).maybeSingle(),
    supabase.from('goals').select('*').eq('user_id', userId).order('created_at', { ascending: false }),
    supabase.from('tasks').select('*').eq('user_id', userId).order('created_at', { ascending: false }),
    supabase.from('habits').select('*').eq('user_id', userId).order('created_at', { ascending: false }),
    supabase.from('habit_logs').select('*').eq('user_id', userId).order('completed_date', { ascending: false }),
  ]);

  return {
    profile: profileRes.data as Profile | null,
    goals: (goalsRes.data as Goal[]) || [],
    tasks: (tasksRes.data as Task[]) || [],
    habits: (habitsRes.data as Habit[]) || [],
    habit_logs: (logsRes.data as HabitLog[]) || [],
    exported_at: new Date().toISOString(),
  };
}

export function downloadJson(data: unknown, filename: string): void {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function deleteAccount(userId: string): Promise<void> {
  const { error } = await supabase.rpc('delete_user_account');
  if (error) throw new Error('Could not delete account. Please try again or contact support.');
}
