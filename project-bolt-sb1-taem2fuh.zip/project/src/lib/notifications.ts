import { supabase } from './supabase';
import { todayISO, formatDate } from './utils';
import type { Goal, Task, Habit, HabitLog, Notification } from '@/types';

/**
 * Generates real notifications based on the user's actual data:
 * - Tasks due today that are still pending
 * - Goals with target dates approaching within 7 days
 * - Habits not yet completed today
 *
 * Deduplicates by checking existing notifications from today with the same type+title.
 * Only creates notifications that don't already exist.
 */
export async function generateNotifications(userId: string): Promise<void> {
  const today = todayISO();

  const [goalsRes, tasksRes, habitsRes, logsRes, existingNotifsRes] = await Promise.all([
    supabase.from('goals').select('*').eq('user_id', userId).eq('status', 'active'),
    supabase.from('tasks').select('*').eq('user_id', userId).eq('status', 'pending'),
    supabase.from('habits').select('*').eq('user_id', userId),
    supabase.from('habit_logs').select('*').eq('user_id', userId).eq('completed_date', today),
    supabase.from('notifications').select('type, title, created_at').eq('user_id', userId).gte('created_at', today),
  ]);

  const goals = (goalsRes.data as Goal[]) || [];
  const tasks = (tasksRes.data as Task[]) || [];
  const habits = (habitsRes.data as Habit[]) || [];
  const todayLogs = (logsRes.data as HabitLog[]) || [];
  const existing = (existingNotifsRes.data as Pick<Notification, 'type' | 'title' | 'created_at'>[]) || [];

  const existingKeys = new Set(existing.map((n) => `${n.type}:${n.title}`));
  const newNotifications: { type: string; title: string; message: string }[] = [];

  // Tasks due today
  for (const task of tasks) {
    if (task.due_date === today) {
      const key = `task_due:${task.title}`;
      if (!existingKeys.has(key)) {
        newNotifications.push({
          type: 'task_due',
          title: 'Task due today',
          message: `"${task.title}" is due today.`,
        });
      }
    }
  }

  // Goals with approaching deadlines (within 7 days)
  const sevenDaysFromNow = new Date();
  sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);
  const sevenDaysStr = sevenDaysFromNow.toISOString().split('T')[0];

  for (const goal of goals) {
    if (goal.target_date && goal.target_date <= sevenDaysStr && goal.target_date >= today) {
      const key = `goal_deadline:${goal.title}`;
      if (!existingKeys.has(key)) {
        newNotifications.push({
          type: 'goal_deadline',
          title: 'Goal deadline approaching',
          message: `"${goal.title}" has a target date of ${formatDate(goal.target_date)}.`,
        });
      }
    }
  }

  // Habits not completed today
  const completedHabitIds = new Set(todayLogs.map((l) => l.habit_id));
  for (const habit of habits) {
    if (habit.frequency === 'Daily' && !completedHabitIds.has(habit.id)) {
      const key = `habit_incomplete:${habit.name}`;
      if (!existingKeys.has(key)) {
        newNotifications.push({
          type: 'habit_incomplete',
          title: 'Habit not completed',
          message: `Don't forget to complete "${habit.name}" today.`,
        });
      }
    }
  }

  if (newNotifications.length > 0) {
    await supabase.from('notifications').insert(
      newNotifications.map((n) => ({
        user_id: userId,
        type: n.type,
        title: n.title,
        message: n.message,
        read: false,
      }))
    );
  }
}
