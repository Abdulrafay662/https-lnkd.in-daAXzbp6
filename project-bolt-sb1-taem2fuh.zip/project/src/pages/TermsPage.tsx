import { Link } from 'react-router-dom';
import { Sun, Moon, FileText } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';

export function TermsPage() {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-white">
      <nav className="sticky top-0 z-40 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <Link to="/"><Logo size="md" /></Link>
          <div className="flex items-center gap-2">
            <button onClick={toggleTheme} className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors" aria-label="Toggle theme">
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            {user ? (
              <Link to="/dashboard" className="btn-primary">Go to Dashboard</Link>
            ) : (
              <>
                <Link to="/signin" className="btn-ghost">Sign In</Link>
                <Link to="/signup" className="btn-primary">Start Free</Link>
              </>
            )}
          </div>
        </div>
      </nav>

      <section className="py-16 lg:py-24">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 mb-6">
            <FileText size={24} className="text-brand-500" />
            <h1 className="text-3xl font-bold">Terms of Service</h1>
          </div>
          <div className="card p-6 space-y-4 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-400 text-xs">
              This is a placeholder terms of service. It should be reviewed by a legal professional before public commercial use.
            </div>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Acceptance of Terms</h2>
              <p>By using LifeOS AI, you agree to these terms. If you do not agree, please do not use the application.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Service Description</h2>
              <p>LifeOS AI is a personal productivity platform that helps you organize goals, tasks, habits, and daily priorities with AI-powered planning. The service is currently provided free of charge.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Your Responsibilities</h2>
              <p>You are responsible for the accuracy of the information you provide. You agree not to misuse the service or attempt to access other users' data.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Data and Privacy</h2>
              <p>Your data is private and belongs to you. You can export or delete your data at any time. See our Privacy Policy for details.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">AI Features</h2>
              <p>AI-generated content is for productivity assistance only. It should not be relied upon as professional advice. The AI does not invent data — it only analyzes your actual activity.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Limitation of Liability</h2>
              <p>LifeOS AI is provided "as is" without warranties. We are not liable for any damages arising from the use of this service.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Changes to Terms</h2>
              <p>We may update these terms from time to time. Continued use of the service constitutes acceptance of updated terms.</p>
            </section>
          </div>
        </div>
      </section>
    </div>
  );
}
