import { useEffect, useState } from 'react';
import { Plus, Target, Pencil, Trash2, CheckCircle2, X, Calendar, AlertCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { formatDate, todayISO, getFriendlyError } from '@/lib/utils';
import { PageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import { Modal } from '@/components/Modal';
import { PriorityBadge, StatusBadge } from '@/components/Badges';
import { GOAL_CATEGORIES, PRIORITIES, type Goal, type GoalCategory, type Priority } from '@/types';
import { generateAiBreakdown } from '@/lib/ai-service';
import { ThinkingIndicator, ErrorBanner } from '@/components/AiComponents';

export function GoalsPage() {
  const { user } = useAuth();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Goal | null>(null);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<GoalCategory>('Personal');
  const [priority, setPriority] = useState<Priority>('Medium');
  const [targetDate, setTargetDate] = useState('');

  // AI breakdown
  const [breakdownOpen, setBreakdownOpen] = useState(false);
  const [breakdownLoading, setBreakdownLoading] = useState(false);
  const [breakdownError, setBreakdownError] = useState('');
  const [breakdownTasks, setBreakdownTasks] = useState<string[]>([]);
  const [selectedTasks, setSelectedTasks] = useState<Set<number>>(new Set());
  const [breakdownGoalTitle, setBreakdownGoalTitle] = useState('');
  const [breakdownGoalDesc, setBreakdownGoalDesc] = useState('');

  useEffect(() => {
    loadGoals();
  }, [user]);

  async function loadGoals() {
    if (!user) return;
    const { data } = await supabase.from('goals').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    setGoals((data as Goal[]) || []);
    setLoading(false);
  }

  function openCreate() {
    setEditingGoal(null);
    setTitle(''); setDescription(''); setCategory('Personal'); setPriority('Medium'); setTargetDate('');
    setFormError('');
    setModalOpen(true);
  }

  function openEdit(goal: Goal) {
    setEditingGoal(goal);
    setTitle(goal.title); setDescription(goal.description || ''); setCategory(goal.category); setPriority(goal.priority); setTargetDate(goal.target_date || '');
    setFormError('');
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError('');
    if (title.trim().length < 2) { setFormError('Goal title cannot be empty.'); return; }
    if (targetDate && new Date(targetDate) < new Date(todayISO())) { setFormError('Target date cannot be in the past.'); return; }

    setSaving(true);
    if (editingGoal) {
      const { error } = await supabase.from('goals').update({ title: title.trim(), description: description.trim(), category, priority, target_date: targetDate || null }).eq('id', editingGoal.id);
      if (error) { setFormError(getFriendlyError(error)); setSaving(false); return; }
    } else {
      const { data, error } = await supabase.from('goals').insert({ title: title.trim(), description: description.trim(), category, priority, target_date: targetDate || null }).select().single();
      if (error) { setFormError(getFriendlyError(error)); setSaving(false); return; }
      setBreakdownGoalTitle(title.trim());
      setBreakdownGoalDesc(description.trim());
      setBreakdownOpen(true);
    }
    setSaving(false);
    setModalOpen(false);
    loadGoals();
  }

  async function toggleComplete(goal: Goal) {
    const newStatus = goal.status === 'completed' ? 'active' : 'completed';
    await supabase.from('goals').update({ status: newStatus }).eq('id', goal.id);
    loadGoals();
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await supabase.from('goals').delete().eq('id', deleteTarget.id);
    setDeleteTarget(null);
    loadGoals();
  }

  async function handleAiBreakdown() {
    if (!breakdownGoalTitle) return;
    setBreakdownLoading(true);
    setBreakdownError('');
    setBreakdownTasks([]);
    setSelectedTasks(new Set());
    try {
      const content = await generateAiBreakdown({ goalTitle: breakdownGoalTitle, goalDescription: breakdownGoalDesc });
      const tasks = content.split('\n').map((t) => t.replace(/^\d+[\.\)]\s*/, '').replace(/^[-•]\s*/, '').trim()).filter((t) => t.length > 0);
      setBreakdownTasks(tasks);
      setSelectedTasks(new Set(tasks.map((_, i) => i)));
    } catch (err) {
      setBreakdownError(getFriendlyError(err));
    } finally {
      setBreakdownLoading(false);
    }
  }

  async function acceptTasks() {
    if (!user) return;
    const goal = goals.find((g) => g.title === breakdownGoalTitle);
    const goalId = goal?.id || null;
    const tasksToCreate = Array.from(selectedTasks).map((i) => breakdownTasks[i]).filter(Boolean);
    if (tasksToCreate.length === 0) { setBreakdownOpen(false); return; }
    const { error } = await supabase.from('tasks').insert(tasksToCreate.map((t) => ({ title: t, goal_id: goalId, priority: 'Medium' as Priority })));
    if (error) { setBreakdownError(getFriendlyError(error)); return; }
    setBreakdownOpen(false);
  }

  if (loading) return <PageLoader />;

  return (
    <div className="space-y-5 max-w-5xl mx-auto animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Goals</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">Create and track your goals.</p>
        </div>
        <button onClick={openCreate} className="btn-primary">
          <Plus size={18} /> Add Goal
        </button>
      </div>

      {goals.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={Target}
            title="Your goals start here."
            description="Create your first goal to start building your plan."
            action={<button onClick={openCreate} className="btn-primary"><Plus size={18} /> Add Goal</button>}
          />
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {goals.map((goal) => (
            <div key={goal.id} className={`card p-5 ${goal.status === 'completed' ? 'opacity-70' : ''}`}>
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className={`font-semibold text-slate-900 dark:text-white ${goal.status === 'completed' ? 'line-through' : ''}`}>{goal.title}</h3>
                <StatusBadge status={goal.status} />
              </div>
              {goal.description && <p className="text-sm text-slate-600 dark:text-slate-400 mb-3 line-clamp-2">{goal.description}</p>}
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className="badge bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">{goal.category}</span>
                <PriorityBadge priority={goal.priority} />
                {goal.target_date && (
                  <span className="badge bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    <Calendar size={12} /> {formatDate(goal.target_date)}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1.5 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button onClick={() => toggleComplete(goal)} className="btn-ghost text-xs px-3 py-1.5">
                  <CheckCircle2 size={14} /> {goal.status === 'completed' ? 'Reopen' : 'Complete'}
                </button>
                <button onClick={() => openEdit(goal)} className="btn-ghost text-xs px-3 py-1.5">
                  <Pencil size={14} /> Edit
                </button>
                <button onClick={() => setDeleteTarget(goal)} className="btn-ghost text-xs px-3 py-1.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30">
                  <Trash2 size={14} /> Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create/Edit modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingGoal ? 'Edit Goal' : 'New Goal'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 text-sm">
              <AlertCircle size={16} className="shrink-0 mt-0.5" /> {formError}
            </div>
          )}
          <div>
            <label htmlFor="goal-title" className="label">Title *</label>
            <input id="goal-title" type="text" value={title} onChange={(e) => setTitle(e.target.value)} className="input" placeholder="e.g., Learn React" required autoFocus />
          </div>
          <div>
            <label htmlFor="goal-desc" className="label">Description</label>
            <textarea id="goal-desc" value={description} onChange={(e) => setDescription(e.target.value)} className="input min-h-[80px] resize-none" placeholder="Describe your goal..." />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="goal-cat" className="label">Category</label>
              <select id="goal-cat" value={category} onChange={(e) => setCategory(e.target.value as GoalCategory)} className="input">
                {GOAL_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="goal-pri" className="label">Priority</label>
              <select id="goal-pri" value={priority} onChange={(e) => setPriority(e.target.value as Priority)} className="input">
                {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label htmlFor="goal-date" className="label">Target Date</label>
            <input id="goal-date" type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} className="input" min={todayISO()} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
            <button type="submit" className="btn-primary" disabled={saving}>{saving ? 'Saving...' : editingGoal ? 'Save Changes' : 'Create Goal'}</button>
          </div>
        </form>
      </Modal>

      {/* AI Breakdown modal */}
      <Modal open={breakdownOpen} onClose={() => setBreakdownOpen(false)} title="AI Task Breakdown" maxWidth="max-w-xl">
        <div className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Let LifeOS AI break down "<span className="font-medium text-slate-900 dark:text-white">{breakdownGoalTitle}</span>" into smaller tasks.
          </p>
          {breakdownTasks.length === 0 && !breakdownLoading && !breakdownError && (
            <button onClick={handleAiBreakdown} className="btn-primary w-full">
              <Target size={18} /> Generate Tasks with AI
            </button>
          )}
          {breakdownLoading && <ThinkingIndicator />}
          {breakdownError && <ErrorBanner message={breakdownError} />}
          {breakdownTasks.length > 0 && (
            <>
              <div className="space-y-2">
                {breakdownTasks.map((task, i) => (
                  <label key={i} className="flex items-center gap-3 p-3 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedTasks.has(i)}
                      onChange={() => {
                        const next = new Set(selectedTasks);
                        if (next.has(i)) next.delete(i); else next.add(i);
                        setSelectedTasks(next);
                      }}
                      className="w-4 h-4 rounded accent-brand-500"
                    />
                    <span className="text-sm text-slate-700 dark:text-slate-300">{task}</span>
                  </label>
                ))}
              </div>
              <div className="flex justify-between gap-2">
                <button onClick={() => setBreakdownOpen(false)} className="btn-secondary">Cancel</button>
                <button onClick={acceptTasks} className="btn-primary">
                  Add {selectedTasks.size} Task{selectedTasks.size !== 1 ? 's' : ''}
                </button>
              </div>
            </>
          )}
        </div>
      </Modal>

      {/* Delete confirmation */}
      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete Goal?">
        <div className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Are you sure you want to delete "<span className="font-medium text-slate-900 dark:text-white">{deleteTarget?.title}</span>"? This action cannot be undone.
          </p>
          <div className="flex justify-end gap-2">
            <button onClick={() => setDeleteTarget(null)} className="btn-secondary">Cancel</button>
            <button onClick={handleDelete} className="btn-danger"><Trash2 size={16} /> Delete</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
