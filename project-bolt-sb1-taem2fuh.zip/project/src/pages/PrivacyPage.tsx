import { Link } from 'react-router-dom';
import { Sun, Moon, Shield } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';

export function PrivacyPage() {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-white">
      <nav className="sticky top-0 z-40 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <Link to="/"><Logo size="md" /></Link>
          <div className="flex items-center gap-2">
            <button onClick={toggleTheme} className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors" aria-label="Toggle theme">
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            {user ? (
              <Link to="/dashboard" className="btn-primary">Go to Dashboard</Link>
            ) : (
              <>
                <Link to="/signin" className="btn-ghost">Sign In</Link>
                <Link to="/signup" className="btn-primary">Start Free</Link>
              </>
            )}
          </div>
        </div>
      </nav>

      <section className="py-16 lg:py-24">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 mb-6">
            <Shield size={24} className="text-brand-500" />
            <h1 className="text-3xl font-bold">Privacy Policy</h1>
          </div>
          <div className="card p-6 space-y-4 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-400 text-xs">
              This is a placeholder privacy policy. It should be reviewed by a legal professional before public commercial use.
            </div>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Your Data Belongs to You</h2>
              <p>LifeOS AI is designed with privacy as a core principle. Each account has completely separate, private data. No other user can access your goals, tasks, habits, or profile information.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Data Storage</h2>
              <p>Your data is stored securely using Supabase with Row Level Security enabled. This means your records are protected at the database level — only you can read, create, update, or delete your own data.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">AI Features</h2>
              <p>When you use AI features, your data is sent to our secure server-side endpoint to generate responses. We do not store your AI conversations beyond what is needed to provide the service. The AI only analyzes your actual data and never invents information.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Data Export</h2>
              <p>You can export all of your data as a JSON file at any time from Settings. This includes your profile, goals, tasks, habits, and habit logs.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">Account Deletion</h2>
              <p>You can permanently delete your account and all associated data at any time from Settings. This action cannot be undone.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slate-900 dark:text-white mb-2">No Fake Statistics</h2>
              <p>LifeOS AI does not fabricate progress statistics. All insights are based on your real activity data.</p>
            </section>
          </div>
        </div>
      </section>
    </div>
  );
}
