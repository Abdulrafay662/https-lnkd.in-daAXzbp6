import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase, GraduationCap, Heart, Sparkles, Building2, FolderKanban, MoreHorizontal, ArrowRight, ArrowLeft, Check } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

const focusOptions = [
  { value: 'Career', icon: Briefcase },
  { value: 'Education', icon: GraduationCap },
  { value: 'Health', icon: Heart },
  { value: 'Personal Growth', icon: Sparkles },
  { value: 'Business', icon: Building2 },
  { value: 'Projects', icon: FolderKanban },
  { value: 'Other', icon: MoreHorizontal },
];

const timeOptions = ['30 minutes', '1 hour', '2 hours', '3+ hours'];

export function OnboardingPage() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [focus, setFocus] = useState('');
  const [goal, setGoal] = useState('');
  const [dailyTime, setDailyTime] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  async function handleFinish() {
    if (!user) return;
    setSaving(true);
    setError('');
    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        onboarding_completed: true,
        onboarding_focus: focus,
        onboarding_goal: goal,
        onboarding_daily_time: dailyTime,
        main_focus: focus,
      })
      .eq('id', user.id);

    setSaving(false);
    if (updateError) {
      setError('Could not save your preferences. Please try again.');
      return;
    }
    await refreshProfile();
    navigate('/dashboard');
  }

  const canProceed = step === 0 ? !!focus : step === 1 ? goal.trim().length >= 3 : step === 2 ? !!dailyTime : true;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
      <header className="p-5">
        <Logo size="md" />
      </header>
      <div className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-xl">
          {/* Progress */}
          <div className="flex items-center justify-center gap-2 mb-8">
            {[0, 1, 2, 3].map((i) => (
              <div
                key={i}
                className={`h-1.5 rounded-full transition-all ${i <= step ? 'w-8 bg-brand-500' : 'w-8 bg-slate-200 dark:bg-slate-800'}`}
              />
            ))}
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 text-sm text-center animate-fade-in-fast">
              {error}
            </div>
          )}

          {step === 0 && (
            <div className="animate-fade-in">
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2 text-center">What would you like LifeOS AI to help you achieve?</h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 text-center mb-6">Choose your main focus area.</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {focusOptions.map((opt) => {
                  const Icon = opt.icon;
                  const selected = focus === opt.value;
                  return (
                    <button
                      key={opt.value}
                      onClick={() => setFocus(opt.value)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${selected ? 'border-brand-500 bg-brand-50 dark:bg-brand-950/30' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'}`}
                    >
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${selected ? 'bg-brand-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'}`}>
                        <Icon size={20} />
                      </div>
                      <span className={`text-sm font-medium ${selected ? 'text-brand-700 dark:text-brand-400' : 'text-slate-700 dark:text-slate-300'}`}>{opt.value}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="animate-fade-in">
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2 text-center">What is your biggest goal right now?</h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 text-center mb-6">Tell us what you want to accomplish.</p>
              <textarea
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                className="input min-h-[120px] resize-none"
                placeholder="e.g., Learn React in 30 days, build my portfolio, or run a 5K..."
                autoFocus
              />
            </div>
          )}

          {step === 2 && (
            <div className="animate-fade-in">
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2 text-center">How much time can you dedicate each day?</h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 text-center mb-6">This helps AI create a realistic plan for you.</p>
              <div className="grid grid-cols-2 gap-3">
                {timeOptions.map((opt) => {
                  const selected = dailyTime === opt;
                  return (
                    <button
                      key={opt}
                      onClick={() => setDailyTime(opt)}
                      className={`p-4 rounded-xl border-2 transition-all text-center ${selected ? 'border-brand-500 bg-brand-50 dark:bg-brand-950/30' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'}`}
                    >
                      <span className={`text-base font-semibold ${selected ? 'text-brand-700 dark:text-brand-400' : 'text-slate-700 dark:text-slate-300'}`}>{opt}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="animate-fade-in text-center">
              <div className="w-16 h-16 rounded-2xl bg-brand-50 dark:bg-brand-950/50 flex items-center justify-center mx-auto mb-4">
                <Check size={32} className="text-brand-500" />
              </div>
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Your LifeOS is ready.</h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Let's start building your plan.</p>
              <div className="card p-4 text-left space-y-2 mb-6">
                <div className="flex justify-between text-sm"><span className="text-slate-500 dark:text-slate-400">Focus</span><span className="font-medium text-slate-900 dark:text-white">{focus}</span></div>
                <div className="flex justify-between text-sm"><span className="text-slate-500 dark:text-slate-400">Goal</span><span className="font-medium text-slate-900 dark:text-white truncate ml-4 max-w-[200px]">{goal}</span></div>
                <div className="flex justify-between text-sm"><span className="text-slate-500 dark:text-slate-400">Daily time</span><span className="font-medium text-slate-900 dark:text-white">{dailyTime}</span></div>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8">
            {step > 0 && step < 3 ? (
              <button onClick={() => setStep(step - 1)} className="btn-ghost">
                <ArrowLeft size={18} /> Back
              </button>
            ) : <div />}
            {step < 3 ? (
              <button onClick={() => canProceed && setStep(step + 1)} className="btn-primary" disabled={!canProceed}>
                Continue <ArrowRight size={18} />
              </button>
            ) : (
              <button onClick={handleFinish} className="btn-primary" disabled={saving}>
                {saving ? 'Setting up...' : 'Create My Plan'} <ArrowRight size={18} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
