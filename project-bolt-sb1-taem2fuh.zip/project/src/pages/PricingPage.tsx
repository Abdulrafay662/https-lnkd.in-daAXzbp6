import { Link } from 'react-router-dom';
import { Check, ArrowRight, Sparkles, Sun, Moon } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';

const features = [
  'Goal management',
  'Task management',
  'Habit tracking',
  'Daily planning',
  'AI features',
  'Progress tracking',
];

export function PricingPage() {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-white">
      <nav className="sticky top-0 z-40 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <Link to="/"><Logo size="md" /></Link>
          <div className="flex items-center gap-2">
            <button onClick={toggleTheme} className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors" aria-label="Toggle theme">
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            {user ? (
              <Link to="/dashboard" className="btn-primary">Go to Dashboard</Link>
            ) : (
              <>
                <Link to="/signin" className="btn-ghost">Sign In</Link>
                <Link to="/signup" className="btn-primary">Start Free</Link>
              </>
            )}
          </div>
        </div>
      </nav>

      <section className="py-16 lg:py-24">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-brand-50 dark:bg-brand-950/50 text-brand-700 dark:text-brand-400 text-xs font-medium mb-6">
            <Sparkles size={14} /> Simple Pricing
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Free during launch</h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 mb-10 max-w-xl mx-auto">
            LifeOS AI is currently available for free. All features included — no payment information required.
          </p>

          <div className="card p-8 max-w-md mx-auto">
            <div className="text-center mb-6">
              <span className="text-sm font-medium text-slate-500 dark:text-slate-400">FREE</span>
              <div className="mt-2 flex items-baseline justify-center gap-1">
                <span className="text-5xl font-bold">$0</span>
                <span className="text-slate-500 dark:text-slate-400">/month</span>
              </div>
            </div>
            <ul className="space-y-3 mb-8 text-left">
              {features.map((f, i) => (
                <li key={i} className="flex items-center gap-2.5 text-sm text-slate-700 dark:text-slate-300">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950/50 flex items-center justify-center shrink-0">
                    <Check size={12} className="text-emerald-600 dark:text-emerald-400" />
                  </div>
                  {f}
                </li>
              ))}
            </ul>
            <Link to="/signup" className="btn-primary w-full">
              Get Started Free <ArrowRight size={18} />
            </Link>
            <p className="text-xs text-slate-400 dark:text-slate-500 text-center mt-4">
              LifeOS AI is currently available for free.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
