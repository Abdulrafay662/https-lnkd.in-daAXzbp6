import { useEffect, useState } from 'react';
import { TrendingUp, Sparkles, Send, Target, CheckSquare, Repeat, Flame } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { getFriendlyError, todayISO } from '@/lib/utils';
import { PageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import { ThinkingIndicator, ErrorBanner, AiResponseDisplay } from '@/components/AiComponents';
import { generateAiReview, type AiReviewInput } from '@/lib/ai-service';
import type { Goal, Task, Habit, HabitLog } from '@/types';

export function ProgressPage() {
  const { user } = useAuth();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [logs, setLogs] = useState<HabitLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [review, setReview] = useState('');
  const [reviewLoading, setReviewLoading] = useState(false);
  const [reviewError, setReviewError] = useState('');

  useEffect(() => { loadData(); }, [user]);

  async function loadData() {
    if (!user) return;
    const [goalsRes, tasksRes, habitsRes, logsRes] = await Promise.all([
      supabase.from('goals').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('tasks').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('habits').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('habit_logs').select('*').eq('user_id', user.id).order('completed_date', { ascending: false }),
    ]);
    setGoals((goalsRes.data as Goal[]) || []);
    setTasks((tasksRes.data as Task[]) || []);
    setHabits((habitsRes.data as Habit[]) || []);
    setLogs((logsRes.data as HabitLog[]) || []);
    setLoading(false);
  }

  async function handleGenerateReview() {
    setReviewError('');
    setReviewLoading(true);
    setReview('');
    try {
      const habitData = habits.map((h) => ({
        name: h.name,
        frequency: h.frequency,
        logs: logs.filter((l) => l.habit_id === h.id).map((l) => l.completed_date),
      }));
      const input: AiReviewInput = {
        goals: goals.map((g) => ({ title: g.title, status: g.status, category: g.category })),
        tasks: tasks.map((t) => ({ title: t.title, status: t.status, priority: t.priority })),
        habits: habitData,
      };
      const result = await generateAiReview(input);
      setReview(result);
    } catch (err) {
      setReviewError(getFriendlyError(err));
    } finally {
      setReviewLoading(false);
    }
  }

  if (loading) return <PageLoader />;

  const completedTasks = tasks.filter((t) => t.status === 'completed').length;
  const pendingTasks = tasks.filter((t) => t.status === 'pending').length;
  const activeGoals = goals.filter((g) => g.status === 'active').length;
  const completedGoals = goals.filter((g) => g.status === 'completed').length;
  const taskRate = tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;

  let maxStreak = 0;
  habits.forEach((h) => {
    const habitLogs = logs.filter((l) => l.habit_id === h.id).map((l) => l.completed_date);
    let streak = 0;
    let date = new Date();
    while (true) {
      const ds = date.toISOString().split('T')[0];
      if (habitLogs.includes(ds)) { streak++; date.setDate(date.getDate() - 1); } else break;
    }
    maxStreak = Math.max(maxStreak, streak);
  });

  const hasData = goals.length > 0 || tasks.length > 0 || habits.length > 0;

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Progress</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">Track your progress and get an AI weekly review.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Task Completion', value: `${taskRate}%`, icon: CheckSquare, color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-950/30' },
          { label: 'Completed Tasks', value: completedTasks, icon: CheckSquare, color: 'text-brand-500', bg: 'bg-brand-50 dark:bg-brand-950/30' },
          { label: 'Active Goals', value: activeGoals, icon: Target, color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-950/30' },
          { label: 'Habit Streak', value: `${maxStreak}d`, icon: Flame, color: 'text-orange-500', bg: 'bg-orange-50 dark:bg-orange-950/30' },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="card p-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg ${s.bg} flex items-center justify-center shrink-0`}>
                  <Icon size={18} className={s.color} />
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{s.label}</p>
                  <p className="text-lg font-bold text-slate-900 dark:text-white">{s.value}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* AI Weekly Review */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles size={18} className="text-brand-500" />
            <h2 className="font-semibold text-slate-900 dark:text-white">AI Weekly Review</h2>
          </div>
          <button onClick={handleGenerateReview} className="btn-primary" disabled={reviewLoading || !hasData}>
            <Send size={16} /> {reviewLoading ? 'Analyzing...' : 'Generate Review'}
          </button>
        </div>

        {!hasData && (
          <EmptyState icon={TrendingUp} title="No data to review yet." description="Add goals, tasks, or habits to get an AI weekly review of your progress." />
        )}

        {hasData && !review && !reviewLoading && !reviewError && (
          <p className="text-sm text-slate-500 dark:text-slate-400">Click "Generate Review" to get an AI analysis of your week based on your actual data.</p>
        )}

        {reviewLoading && <ThinkingIndicator />}
        {reviewError && <ErrorBanner message={reviewError} />}
        {review && (
          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <AiResponseDisplay content={review} />
          </div>
        )}
      </div>
    </div>
  );
}
