import { useEffect, useState } from 'react';
import { CalendarDays, Sun, Cloud, Moon, CheckCircle2, Circle, Sparkles, Send, AlertCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { todayISO, getFriendlyError } from '@/lib/utils';
import { PageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import { PriorityBadge } from '@/components/Badges';
import { ThinkingIndicator, ErrorBanner, AiResponseDisplay } from '@/components/AiComponents';
import { generateAiPlan, type AiPlanInput } from '@/lib/ai-service';
import type { Task } from '@/types';

export function PlannerPage() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  // AI Planner form
  const [goal, setGoal] = useState('');
  const [hours, setHours] = useState('');
  const [deadline, setDeadline] = useState('');
  const [progress, setProgress] = useState('');
  const [importantTasks, setImportantTasks] = useState('');
  const [constraints, setConstraints] = useState('');
  const [planResult, setPlanResult] = useState('');
  const [planLoading, setPlanLoading] = useState(false);
  const [planError, setPlanError] = useState('');

  useEffect(() => { loadTasks(); }, [user]);

  async function loadTasks() {
    if (!user) return;
    const { data } = await supabase.from('tasks').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    setTasks((data as Task[]) || []);
    setLoading(false);
  }

  const today = todayISO();
  const pendingTasks = tasks.filter((t) => t.status === 'pending');
  const priorityOrder: Record<string, number> = { High: 0, Medium: 1, Low: 2 };
  const sortedTasks = [...pendingTasks].sort((a, b) => {
    if (a.due_date !== b.due_date) {
      if (!a.due_date) return 1; if (!b.due_date) return -1;
      return a.due_date.localeCompare(b.due_date);
    }
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  const morning = sortedTasks.filter((t) => t.priority === 'High');
  const afternoon = sortedTasks.filter((t) => t.priority === 'Medium');
  const evening = sortedTasks.filter((t) => t.priority === 'Low');

  async function handleGeneratePlan(e: React.FormEvent) {
    e.preventDefault();
    setPlanError('');
    if (goal.trim().length < 3) { setPlanError('Please describe your goal.'); return; }
    setPlanLoading(true);
    setPlanResult('');
    try {
      const input: AiPlanInput = { goal: goal.trim(), hours, deadline, progress, tasks: importantTasks, constraints };
      const result = await generateAiPlan(input);
      setPlanResult(result);
    } catch (err) {
      setPlanError(getFriendlyError(err));
    } finally {
      setPlanLoading(false);
    }
  }

  if (loading) return <PageLoader />;

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">AI Planner</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">Organize your day and generate AI-powered plans.</p>
      </div>

      {/* Today's Plan */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <CalendarDays size={18} className="text-brand-500" />
          <h2 className="font-semibold text-slate-900 dark:text-white">Today's Plan</h2>
        </div>
        {pendingTasks.length === 0 ? (
          <div className="card">
            <EmptyState icon={CalendarDays} title="Your day is clear." description="No pending tasks. Enjoy your day or add a new task." />
          </div>
        ) : (
          <div className="space-y-4">
            <TimeBlock icon={Sun} label="Morning" subtitle="High-priority tasks" tasks={morning} color="text-amber-500" bg="bg-amber-50 dark:bg-amber-950/20" />
            <TimeBlock icon={Cloud} label="Afternoon" subtitle="Medium-priority tasks" tasks={afternoon} color="text-sky-500" bg="bg-sky-50 dark:bg-sky-950/20" />
            <TimeBlock icon={Moon} label="Evening" subtitle="Remaining tasks" tasks={evening} color="text-indigo-500" bg="bg-indigo-50 dark:bg-indigo-950/20" />
          </div>
        )}
      </div>

      {/* AI Plan Generator */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles size={18} className="text-brand-500" />
          <h2 className="font-semibold text-slate-900 dark:text-white">Generate an AI Plan</h2>
        </div>
        <form onSubmit={handleGeneratePlan} className="space-y-4">
          <div>
            <label htmlFor="plan-goal" className="label">Main Goal *</label>
            <input id="plan-goal" type="text" value={goal} onChange={(e) => setGoal(e.target.value)} className="input" placeholder="e.g., Learn React in 30 days" required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="plan-hours" className="label">Available Hours/Day</label>
              <input id="plan-hours" type="text" value={hours} onChange={(e) => setHours(e.target.value)} className="input" placeholder="e.g., 2 hours" />
            </div>
            <div>
              <label htmlFor="plan-deadline" className="label">Deadline</label>
              <input id="plan-deadline" type="text" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="input" placeholder="e.g., 30 days" />
            </div>
          </div>
          <div>
            <label htmlFor="plan-progress" className="label">Current Progress</label>
            <input id="plan-progress" type="text" value={progress} onChange={(e) => setProgress(e.target.value)} className="input" placeholder="e.g., Just starting" />
          </div>
          <div>
            <label htmlFor="plan-tasks" className="label">Important Tasks</label>
            <textarea id="plan-tasks" value={importantTasks} onChange={(e) => setImportantTasks(e.target.value)} className="input min-h-[60px] resize-none" placeholder="List any tasks you know you need to do..." />
          </div>
          <div>
            <label htmlFor="plan-constraints" className="label">Personal Constraints</label>
            <textarea id="plan-constraints" value={constraints} onChange={(e) => setConstraints(e.target.value)} className="input min-h-[60px] resize-none" placeholder="e.g., Weekends only, no mornings..." />
          </div>
          {planError && <ErrorBanner message={planError} />}
          <button type="submit" className="btn-primary w-full" disabled={planLoading}>
            <Send size={18} /> {planLoading ? 'Generating...' : 'Generate Plan'}
          </button>
        </form>
        {planLoading && <div className="mt-4"><ThinkingIndicator /></div>}
        {planResult && (
          <div className="mt-4 p-4 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <AiResponseDisplay content={planResult} />
          </div>
        )}
      </div>
    </div>
  );
}

function TimeBlock({ icon: Icon, label, subtitle, tasks, color, bg }: { icon: typeof Sun; label: string; subtitle: string; tasks: Task[]; color: string; bg: string }) {
  return (
    <div className="card p-4">
      <div className="flex items-center gap-2 mb-3">
        <div className={`w-8 h-8 rounded-lg ${bg} flex items-center justify-center`}>
          <Icon size={16} className={color} />
        </div>
        <div>
          <h3 className="font-medium text-slate-900 dark:text-white text-sm">{label}</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>
        </div>
      </div>
      {tasks.length === 0 ? (
        <p className="text-sm text-slate-400 dark:text-slate-500 py-2">No tasks in this block.</p>
      ) : (
        <div className="space-y-2">
          {tasks.map((t) => (
            <div key={t.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50">
              <Circle size={16} className="text-slate-300 dark:text-slate-600 shrink-0" />
              <span className="text-sm text-slate-700 dark:text-slate-300 flex-1">{t.title}</span>
              <PriorityBadge priority={t.priority} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
