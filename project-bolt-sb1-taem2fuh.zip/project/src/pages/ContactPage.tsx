import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, MessageSquare, User, Send, Sun, Moon, AlertCircle, Info } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { isValidEmail } from '@/lib/utils';

export function ContactPage() {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setInfo('');
    if (name.trim().length < 2) { setError('Please enter your name.'); return; }
    if (!isValidEmail(email)) { setError('Please enter a valid email address.'); return; }
    if (message.trim().length < 10) { setError('Message must be at least 10 characters.'); return; }
    setInfo('This contact form is not yet connected to an email service. Please configure an email backend before this form can send messages.');
  }

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-white">
      <nav className="sticky top-0 z-40 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <Link to="/"><Logo size="md" /></Link>
          <div className="flex items-center gap-2">
            <button onClick={toggleTheme} className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors" aria-label="Toggle theme">
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            {user ? (
              <Link to="/dashboard" className="btn-primary">Go to Dashboard</Link>
            ) : (
              <>
                <Link to="/signin" className="btn-ghost">Sign In</Link>
                <Link to="/signup" className="btn-primary">Start Free</Link>
              </>
            )}
          </div>
        </div>
      </nav>

      <section className="py-16 lg:py-24">
        <div className="max-w-lg mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl sm:text-4xl font-bold mb-3">Contact Us</h1>
            <p className="text-slate-600 dark:text-slate-400">Have a question or feedback? We'd love to hear from you.</p>
          </div>
          <div className="card p-6">
            {info && (
              <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-400 text-sm mb-4">
                <Info size={16} className="shrink-0 mt-0.5" /> {info}
              </div>
            )}
            {error && (
              <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 text-sm mb-4">
                <AlertCircle size={16} className="shrink-0 mt-0.5" /> {error}
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="contact-name" className="label">Name</label>
                <div className="relative">
                  <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input id="contact-name" type="text" value={name} onChange={(e) => setName(e.target.value)} className="input pl-10" placeholder="Your name" required />
                </div>
              </div>
              <div>
                <label htmlFor="contact-email" className="label">Email</label>
                <div className="relative">
                  <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input id="contact-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="input pl-10" placeholder="you@example.com" required />
                </div>
              </div>
              <div>
                <label htmlFor="contact-message" className="label">Message</label>
                <div className="relative">
                  <MessageSquare size={18} className="absolute left-3 top-3 text-slate-400" />
                  <textarea id="contact-message" value={message} onChange={(e) => setMessage(e.target.value)} className="input pl-10 min-h-[120px] resize-none" placeholder="Your message..." required />
                </div>
              </div>
              <button type="submit" className="btn-primary w-full">
                <Send size={18} /> Send Message
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}
