import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Brain, Target, CheckSquare, Repeat, CalendarDays, TrendingUp,
  Bot, Sparkles, ArrowRight, Menu, X, ChevronDown, Shield,
  Clock, Zap, Layers, CheckCircle2, Sun, Moon, Lock, Eye, UserX,
} from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';

const features = [
  { icon: Brain, title: 'AI Life Planning', desc: 'Turn your biggest goals into structured, achievable plans with AI-powered planning.' },
  { icon: Layers, title: 'Smart Task Breakdown', desc: 'Break any goal into smaller, actionable tasks automatically with one click.' },
  { icon: Target, title: 'Goal Management', desc: 'Create, organize, and track goals across categories with priorities and deadlines.' },
  { icon: Repeat, title: 'Habit Tracking', desc: 'Build consistent habits with visual streaks, completion counts, and daily check-ins.' },
  { icon: CalendarDays, title: 'Daily Planning', desc: 'Organize your day by priority and due date with a clean morning, afternoon, evening view.' },
  { icon: TrendingUp, title: 'AI Weekly Review', desc: 'Get an honest weekly analysis of your progress, problems, and next priorities.' },
  { icon: Bot, title: 'AI Life Assistant', desc: 'Ask questions about your goals, tasks, and habits — answered from your actual data.' },
  { icon: Sparkles, title: 'Progress Insights', desc: 'Understand your completion rates, streaks, and momentum at a glance.' },
];

const benefits = [
  { icon: Shield, title: 'Reduce Overwhelm', desc: 'Break big goals into small, manageable steps so you always know what to do next.' },
  { icon: Layers, title: 'Stay Organized', desc: 'Keep goals, tasks, and habits in one clean dashboard — no more scattered notes.' },
  { icon: Zap, title: 'Prioritize Important Work', desc: 'AI helps you focus on what matters most, not just what feels urgent.' },
  { icon: Repeat, title: 'Build Consistent Habits', desc: 'Visual streaks and daily reminders keep you on track day after day.' },
  { icon: TrendingUp, title: 'Understand Progress', desc: 'See exactly how far you have come and what needs attention.' },
];

const steps = [
  { icon: Target, title: 'Add your goals', desc: 'Tell LifeOS AI what you want to achieve — from learning a skill to building a business.' },
  { icon: Brain, title: 'AI turns them into tasks', desc: 'LifeOS AI breaks your goals into actionable steps and organizes them by priority.' },
  { icon: TrendingUp, title: 'Track and improve', desc: 'Complete tasks, build habits, review progress, and adapt your plan over time.' },
];

const faqs = [
  { q: 'What is LifeOS AI?', a: 'LifeOS AI is a personal productivity platform that uses AI to help you organize goals, tasks, habits, and daily priorities into an actionable plan.' },
  { q: 'Is LifeOS AI free?', a: 'Yes, LifeOS AI is currently available for free during this initial launch. All core features are included at no cost.' },
  { q: 'How does AI planning work?', a: 'You provide your goal, available time, deadline, and constraints. LifeOS AI generates a structured plan with weekly milestones, daily tasks, and recommended order.' },
  { q: 'Can I create my own goals?', a: 'Absolutely. You can create goals across categories like Career, Education, Health, Finance, and more, each with its own priority and target date.' },
  { q: 'Can I track habits?', a: 'Yes. Create daily or weekly habits, mark them complete each day, and see your current streak and completion history.' },
  { q: 'Is my data private?', a: 'Your data belongs to you. Each account has completely private data protected by database-level security. No other user can access your information.' },
  { q: 'Can I delete my account?', a: 'Yes. You can delete your account and all associated data at any time from Settings. This action is permanent and cannot be undone.' },
];

export function LandingPage() {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-white">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/"><Logo size="md" /></Link>
            <div className="hidden md:flex items-center gap-1">
              <a href="#features" className="px-3 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">Features</a>
              <a href="#how" className="px-3 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">How It Works</a>
              <Link to="/pricing" className="px-3 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">Pricing</Link>
              <a href="#faq" className="px-3 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">FAQ</a>
            </div>
            <div className="hidden md:flex items-center gap-2">
              <button onClick={toggleTheme} className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors" aria-label="Toggle theme">
                {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              {user ? (
                <Link to="/dashboard" className="btn-primary">Go to Dashboard</Link>
              ) : (
                <>
                  <Link to="/signin" className="btn-ghost">Sign In</Link>
                  <Link to="/signup" className="btn-primary">Start Free</Link>
                </>
              )}
            </div>
            <div className="md:hidden flex items-center gap-2">
              <button onClick={toggleTheme} className="p-2 rounded-lg text-slate-600 dark:text-slate-300" aria-label="Toggle theme">
                {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="p-2 rounded-lg text-slate-600 dark:text-slate-300" aria-label="Toggle menu">
                {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-3 space-y-1 animate-fade-in-fast">
            <a href="#features" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800">Features</a>
            <a href="#how" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800">How It Works</a>
            <Link to="/pricing" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800">Pricing</Link>
            <a href="#faq" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800">FAQ</a>
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-col gap-2">
              {user ? (
                <Link to="/dashboard" onClick={() => setMobileMenuOpen(false)} className="btn-primary w-full">Go to Dashboard</Link>
              ) : (
                <>
                  <Link to="/signin" onClick={() => setMobileMenuOpen(false)} className="btn-secondary w-full">Sign In</Link>
                  <Link to="/signup" onClick={() => setMobileMenuOpen(false)} className="btn-primary w-full">Start Free</Link>
                </>
              )}
            </div>
          </div>
        )}
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-brand-50/50 via-transparent to-transparent dark:from-brand-950/30" />
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-brand-500/10 rounded-full blur-3xl" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 lg:pt-24 lg:pb-28">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-brand-50 dark:bg-brand-950/50 text-brand-700 dark:text-brand-400 text-xs font-medium mb-6 animate-fade-in">
              <Sparkles size={14} />
              AI-Powered Personal Productivity
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-5 animate-fade-in">
              Your Life. <span className="text-brand-500">Organized by AI.</span>
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 mb-8 max-w-2xl mx-auto leading-relaxed animate-fade-in">
              LifeOS AI turns your goals, tasks, habits, and priorities into an intelligent plan that helps you make consistent progress.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 animate-fade-in">
              <Link to="/signup" className="btn-primary w-full sm:w-auto">
                Start for Free <ArrowRight size={18} />
              </Link>
              <a href="#how" className="btn-outline w-full sm:w-auto">See How It Works</a>
            </div>
          </div>

          {/* Hero illustration */}
          <div className="mt-16 max-w-4xl mx-auto">
            <div className="card p-6 lg:p-8 bg-gradient-to-br from-white to-slate-50 dark:from-slate-900 dark:to-slate-950">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { icon: Target, label: 'Goals', value: '4 Active', color: 'text-brand-500' },
                  { icon: CheckSquare, label: 'Tasks', value: '12 Today', color: 'text-emerald-500' },
                  { icon: Repeat, label: 'Habits', value: '7-Day Streak', color: 'text-amber-500' },
                  { icon: TrendingUp, label: 'Progress', value: '78% This Week', color: 'text-purple-500' },
                ].map((stat, i) => {
                  const Icon = stat.icon;
                  return (
                    <div key={i} className="flex flex-col items-center text-center p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                      <div className={`w-12 h-12 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center mb-3 ${stat.color}`}>
                        <Icon size={24} />
                      </div>
                      <span className="text-xs text-slate-500 dark:text-slate-400">{stat.label}</span>
                      <span className="text-sm font-semibold text-slate-900 dark:text-white">{stat.value}</span>
                    </div>
                  );
                })}
              </div>
              <div className="mt-4 p-4 rounded-xl bg-brand-50 dark:bg-brand-950/30 border border-brand-100 dark:border-brand-900">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-brand-500 flex items-center justify-center shrink-0">
                    <Bot size={16} className="text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-white">AI Daily Focus</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">"Complete your React learning task before noon, then review your portfolio goal progress."</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem */}
      <section className="py-16 lg:py-20 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Productivity tools don't plan for you.</h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Most apps give you a blank list and leave you to figure out the rest. LifeOS AI takes your goals and builds the plan — so you spend less time organizing and more time doing.
          </p>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-3">How LifeOS AI Works</h2>
            <p className="text-slate-600 dark:text-slate-400 max-w-xl mx-auto">Three simple steps to turn your goals into consistent progress.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {steps.map((step, i) => {
              const Icon = step.icon;
              return (
                <div key={i} className="card p-6 text-center relative">
                  <div className="absolute top-4 right-4 text-5xl font-bold text-slate-100 dark:text-slate-800 select-none">{i + 1}</div>
                  <div className="w-14 h-14 rounded-2xl bg-brand-50 dark:bg-brand-950/50 flex items-center justify-center mx-auto mb-4">
                    <Icon size={26} className="text-brand-500" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">{step.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-16 lg:py-24 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-3">Everything you need to stay on track</h2>
            <p className="text-slate-600 dark:text-slate-400 max-w-xl mx-auto">AI-powered features that help you plan, execute, and review your progress.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {features.map((f, i) => {
              const Icon = f.icon;
              return (
                <div key={i} className="card p-5 hover:shadow-md transition-shadow group">
                  <div className="w-11 h-11 rounded-xl bg-brand-50 dark:bg-brand-950/50 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <Icon size={20} className="text-brand-500" />
                  </div>
                  <h3 className="font-semibold mb-1.5">{f.title}</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* AI Capabilities */}
      <section className="py-16 lg:py-24">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="card p-8 lg:p-12 bg-gradient-to-br from-brand-50 to-slate-50 dark:from-slate-900 dark:to-slate-950 border-brand-100 dark:border-slate-800">
            <div className="flex flex-col lg:flex-row items-start gap-8">
              <div className="lg:w-1/2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 dark:bg-brand-950 text-brand-700 dark:text-brand-400 text-xs font-medium mb-4">
                  <Sparkles size={14} /> AI Capabilities
                </div>
                <h2 className="text-2xl lg:text-3xl font-bold mb-4">Your AI planning assistant</h2>
                <p className="text-slate-600 dark:text-slate-400 mb-6">LifeOS AI uses your actual data to generate plans, break down goals, review your week, and answer questions about your progress — without inventing information.</p>
                <ul className="space-y-3">
                  {['AI Planner creates structured plans from your goals', 'AI Task Breakdown splits goals into tasks', 'AI Weekly Review analyzes your real progress', 'AI Assistant answers questions from your data'].map((item, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700 dark:text-slate-300">
                      <CheckCircle2 size={18} className="text-brand-500 shrink-0 mt-0.5" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="lg:w-1/2 space-y-3">
                <div className="card p-4 bg-white dark:bg-slate-900">
                  <div className="flex items-center gap-2 mb-2">
                    <Bot size={16} className="text-brand-500" />
                    <span className="text-xs font-medium text-slate-500 dark:text-slate-400">AI Assistant</span>
                  </div>
                  <p className="text-sm text-slate-700 dark:text-slate-300">"What should I focus on today?"</p>
                  <div className="mt-2 p-3 rounded-lg bg-brand-50 dark:bg-brand-950/30 text-sm text-slate-600 dark:text-slate-400">
                    "You have 3 high-priority tasks due today. Start with 'Complete React hooks lesson' — it supports your learning goal."
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 lg:py-24 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-3">Why LifeOS AI?</h2>
            <p className="text-slate-600 dark:text-slate-400 max-w-xl mx-auto">Built to help you make real, consistent progress.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {benefits.map((b, i) => {
              const Icon = b.icon;
              return (
                <div key={i} className="flex items-start gap-4 p-5 card">
                  <div className="w-11 h-11 rounded-xl bg-brand-50 dark:bg-brand-950/50 flex items-center justify-center shrink-0">
                    <Icon size={20} className="text-brand-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">{b.title}</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">{b.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Trust */}
      <section className="py-16 lg:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 text-xs font-medium mb-6">
            <Shield size={14} /> Privacy First
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Your data belongs to you.</h2>
          <div className="grid sm:grid-cols-3 gap-6 mt-10">
            {[
              { icon: Lock, title: 'Private by Design', desc: 'Each account has completely separate data. No other user can access your goals, tasks, or habits.' },
              { icon: Eye, title: 'No Invented Data', desc: 'LifeOS AI only analyzes your actual activity. It never fabricates progress or statistics.' },
              { icon: UserX, title: 'Delete Anytime', desc: 'Export your data or delete your account permanently at any time from Settings.' },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} className="text-center">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 flex items-center justify-center mx-auto mb-3">
                    <Icon size={24} className="text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <h3 className="font-semibold mb-1.5">{item.title}</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">{item.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-16 lg:py-24 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl sm:text-4xl font-bold mb-3">Frequently Asked Questions</h2>
          </div>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div key={i} className="card overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="flex items-center justify-between w-full p-4 text-left"
                  aria-expanded={openFaq === i}
                >
                  <span className="font-medium text-slate-900 dark:text-white pr-4">{faq.q}</span>
                  <ChevronDown size={20} className={`shrink-0 text-slate-400 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === i && (
                  <div className="px-4 pb-4 text-sm text-slate-600 dark:text-slate-400 animate-fade-in-fast">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 lg:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="card p-8 lg:p-12 text-center bg-gradient-to-br from-brand-600 to-brand-800 border-0">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Start organizing your life with AI.</h2>
            <p className="text-brand-100 mb-8 max-w-xl mx-auto">Join LifeOS AI today — free during launch. Turn your goals into a plan you can actually follow.</p>
            <Link to="/signup" className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-white text-brand-700 font-semibold hover:bg-brand-50 transition-colors">
              Get Started Free <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <Logo size="sm" />
            <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm text-slate-500 dark:text-slate-400">
              <a href="#features" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">Features</a>
              <Link to="/pricing" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">Pricing</Link>
              <Link to="/contact" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">Contact</Link>
              <Link to="/privacy" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">Privacy</Link>
              <Link to="/terms" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">Terms</Link>
            </div>
            <p className="text-xs text-slate-400 dark:text-slate-500">LifeOS AI — Your Life, Organized by AI.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
