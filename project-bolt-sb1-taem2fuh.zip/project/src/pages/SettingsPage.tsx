import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User, Sun, Moon, Download, Trash2, LogOut, AlertCircle, Check, Save,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { supabase } from '@/lib/supabase';
import { getFriendlyError } from '@/lib/utils';
import { Avatar } from '@/components/Avatar';
import { Modal } from '@/components/Modal';
import { exportUserData, downloadJson, deleteAccount } from '@/lib/data-export';

export function SettingsPage() {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [description, setDescription] = useState(profile?.description || '');
  const [mainFocus, setMainFocus] = useState(profile?.main_focus || '');
  const [timeZone, setTimeZone] = useState(profile?.time_zone || '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState('');
  const [deleting, setDeleting] = useState(false);

  async function handleSaveProfile(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setError('');
    setSaving(true);
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ full_name: fullName.trim(), description: description.trim(), main_focus: mainFocus.trim(), time_zone: timeZone.trim(), updated_at: new Date().toISOString() })
      .eq('id', user.id);
    setSaving(false);
    if (updateError) { setError(getFriendlyError(updateError)); return; }
    await refreshProfile();
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  async function handleExport() {
    if (!user) return;
    try {
      const data = await exportUserData(user.id);
      downloadJson(data, `lifeos-export-${new Date().toISOString().split('T')[0]}.json`);
    } catch {
      setError('Could not export data. Please try again.');
    }
  }

  async function handleDeleteAccount() {
    if (deleteConfirm !== 'DELETE') return;
    setDeleting(true);
    try {
      await deleteAccount(user!.id);
      await signOut();
      navigate('/');
    } catch (err) {
      setError(getFriendlyError(err));
      setDeleting(false);
    }
  }

  async function handleSignOut() {
    await signOut();
    navigate('/');
  }

  return (
    <div className="space-y-6 max-w-2xl mx-auto animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Settings</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">Manage your account and preferences.</p>
      </div>

      {error && (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 text-sm">
          <AlertCircle size={16} className="shrink-0 mt-0.5" /> {error}
        </div>
      )}

      {/* Profile */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-4">
          <User size={18} className="text-brand-500" />
          <h2 className="font-semibold text-slate-900 dark:text-white">Profile</h2>
        </div>
        <form onSubmit={handleSaveProfile} className="space-y-4">
          <div className="flex items-center gap-4">
            <Avatar name={profile?.full_name} url={profile?.avatar_url} size="lg" />
            <div>
              <p className="text-sm font-medium text-slate-900 dark:text-white">{profile?.full_name || 'Your name'}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{user?.email}</p>
            </div>
          </div>
          <div>
            <label htmlFor="settings-name" className="label">Full Name</label>
            <input id="settings-name" type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} className="input" placeholder="Your name" />
          </div>
          <div>
            <label htmlFor="settings-desc" className="label">Short Description</label>
            <textarea id="settings-desc" value={description} onChange={(e) => setDescription(e.target.value)} className="input min-h-[70px] resize-none" placeholder="Tell us about yourself..." />
          </div>
          <div>
            <label htmlFor="settings-focus" className="label">Main Focus</label>
            <input id="settings-focus" type="text" value={mainFocus} onChange={(e) => setMainFocus(e.target.value)} className="input" placeholder="e.g., Career, Health" />
          </div>
          <div>
            <label htmlFor="settings-tz" className="label">Time Zone</label>
            <input id="settings-tz" type="text" value={timeZone} onChange={(e) => setTimeZone(e.target.value)} className="input" placeholder="e.g., America/New_York" />
          </div>
          <div className="flex justify-end">
            <button type="submit" className="btn-primary" disabled={saving}>
              {saved ? <><Check size={16} /> Saved</> : <><Save size={16} /> {saving ? 'Saving...' : 'Save Changes'}</>}
            </button>
          </div>
        </form>
      </div>

      {/* Theme */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-4">
          {theme === 'dark' ? <Moon size={18} className="text-brand-500" /> : <Sun size={18} className="text-brand-500" />}
          <h2 className="font-semibold text-slate-900 dark:text-white">Theme Preference</h2>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setTheme('light')}
            className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border-2 transition-all ${theme === 'light' ? 'border-brand-500 bg-brand-50 dark:bg-brand-950/30' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'}`}
          >
            <Sun size={18} className={theme === 'light' ? 'text-brand-500' : 'text-slate-400'} />
            <span className={`text-sm font-medium ${theme === 'light' ? 'text-brand-700 dark:text-brand-400' : 'text-slate-600 dark:text-slate-400'}`}>Light</span>
          </button>
          <button
            onClick={() => setTheme('dark')}
            className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border-2 transition-all ${theme === 'dark' ? 'border-brand-500 bg-brand-50 dark:bg-brand-950/30' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'}`}
          >
            <Moon size={18} className={theme === 'dark' ? 'text-brand-500' : 'text-slate-400'} />
            <span className={`text-sm font-medium ${theme === 'dark' ? 'text-brand-700 dark:text-brand-400' : 'text-slate-600 dark:text-slate-400'}`}>Dark</span>
          </button>
        </div>
      </div>

      {/* Data */}
      <div className="card p-5">
        <h2 className="font-semibold text-slate-900 dark:text-white mb-4">Data & Privacy</h2>
        <div className="space-y-3">
          <button onClick={handleExport} className="w-full flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
            <div className="flex items-center gap-3">
              <Download size={18} className="text-brand-500" />
              <div className="text-left">
                <p className="text-sm font-medium text-slate-900 dark:text-white">Export My Data</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Download your data as JSON</p>
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Danger zone */}
      <div className="card p-5 border-red-200 dark:border-red-900">
        <h2 className="font-semibold text-red-600 dark:text-red-400 mb-4">Danger Zone</h2>
        <div className="space-y-3">
          <button onClick={handleSignOut} className="w-full flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
            <div className="flex items-center gap-3">
              <LogOut size={18} className="text-slate-500" />
              <div className="text-left">
                <p className="text-sm font-medium text-slate-900 dark:text-white">Sign Out</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Sign out of your account</p>
              </div>
            </div>
          </button>
          <button onClick={() => setDeleteOpen(true)} className="w-full flex items-center justify-between p-3 rounded-lg border border-red-200 dark:border-red-900 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors">
            <div className="flex items-center gap-3">
              <Trash2 size={18} className="text-red-500" />
              <div className="text-left">
                <p className="text-sm font-medium text-red-600 dark:text-red-400">Delete Account</p>
                <p className="text-xs text-red-400 dark:text-red-500">Permanently delete your account and data</p>
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Delete confirmation */}
      <Modal open={deleteOpen} onClose={() => { setDeleteOpen(false); setDeleteConfirm(''); }} title="Delete Account?">
        <div className="space-y-4">
          <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 text-sm">
            This permanently deletes your LifeOS account and associated data. This action cannot be undone.
          </div>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Type <span className="font-bold text-red-600 dark:text-red-400">DELETE</span> to confirm:
          </p>
          <input type="text" value={deleteConfirm} onChange={(e) => setDeleteConfirm(e.target.value)} className="input" placeholder="Type DELETE" />
          <div className="flex justify-end gap-2">
            <button onClick={() => { setDeleteOpen(false); setDeleteConfirm(''); }} className="btn-secondary">Cancel</button>
            <button onClick={handleDeleteAccount} className="btn-danger" disabled={deleteConfirm !== 'DELETE' || deleting}>
              <Trash2 size={16} /> {deleting ? 'Deleting...' : 'Delete Account'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
