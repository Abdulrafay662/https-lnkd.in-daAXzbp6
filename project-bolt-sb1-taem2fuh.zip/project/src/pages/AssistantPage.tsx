import { useEffect, useRef, useState } from 'react';
import { Bot, Send, Trash2, Sparkles } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { getFriendlyError } from '@/lib/utils';
import { ThinkingIndicator, ErrorBanner } from '@/components/AiComponents';
import { generateAiAssistantReply, type AiChatMessage, type AiReviewInput } from '@/lib/ai-service';
import type { Goal, Task, Habit, HabitLog } from '@/types';

const suggestedQuestions = [
  'What should I focus on today?',
  'Which goal am I neglecting?',
  'What tasks should I complete first?',
  'How am I progressing this week?',
  'I have two hours today. What should I do?',
];

export function AssistantPage() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<AiChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [dataLoaded, setDataLoaded] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { loadData(); }, [user]);
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  async function loadData() {
    if (!user) return;
    setDataLoaded(true);
  }

  async function sendMessage(text: string) {
    if (!text.trim() || loading) return;
    setError('');
    const userMsg: AiChatMessage = { role: 'user', content: text.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const [goalsRes, tasksRes, habitsRes, logsRes] = await Promise.all([
        supabase.from('goals').select('*').eq('user_id', user!.id),
        supabase.from('tasks').select('*').eq('user_id', user!.id),
        supabase.from('habits').select('*').eq('user_id', user!.id),
        supabase.from('habit_logs').select('*').eq('user_id', user!.id),
      ]);
      const goals = (goalsRes.data as Goal[]) || [];
      const tasks = (tasksRes.data as Task[]) || [];
      const habits = (habitsRes.data as Habit[]) || [];
      const logs = (logsRes.data as HabitLog[]) || [];

      const context: AiReviewInput = {
        goals: goals.map((g) => ({ title: g.title, status: g.status, category: g.category })),
        tasks: tasks.map((t) => ({ title: t.title, status: t.status, priority: t.priority })),
        habits: habits.map((h) => ({
          name: h.name,
          frequency: h.frequency,
          logs: logs.filter((l) => l.habit_id === h.id).map((l) => l.completed_date),
        })),
      };

      const history = [...messages, userMsg];
      const reply = await generateAiAssistantReply(history, context);
      setMessages((prev) => [...prev, { role: 'assistant', content: reply }]);
    } catch (err) {
      setError(getFriendlyError(err));
    } finally {
      setLoading(false);
    }
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    sendMessage(input);
  }

  function clearConversation() {
    setMessages([]);
    setError('');
  }

  return (
    <div className="max-w-3xl mx-auto animate-fade-in h-[calc(100vh-8rem)] flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-brand-500 flex items-center justify-center">
            <Bot size={20} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">AI Assistant</h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">Powered by your LifeOS data</p>
          </div>
        </div>
        {messages.length > 0 && (
          <button onClick={clearConversation} className="btn-ghost text-sm">
            <Trash2 size={16} /> Clear
          </button>
        )}
      </div>

      <div className="card flex-1 flex flex-col overflow-hidden">
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && !loading && (
            <div className="flex flex-col items-center justify-center h-full text-center py-8">
              <div className="w-16 h-16 rounded-2xl bg-brand-50 dark:bg-brand-950/50 flex items-center justify-center mb-4">
                <Sparkles size={28} className="text-brand-500" />
              </div>
              <h3 className="font-semibold text-slate-900 dark:text-white mb-1.5">Start a conversation with LifeOS AI.</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 max-w-sm">Ask about your goals, tasks, habits, or what to focus on. The assistant uses your actual data.</p>
              <div className="flex flex-wrap gap-2 justify-center max-w-md">
                {suggestedQuestions.map((q, i) => (
                  <button key={i} onClick={() => sendMessage(q)} className="px-3 py-1.5 rounded-lg text-sm bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-brand-50 dark:hover:bg-brand-950/30 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''} animate-fade-in`}>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-slate-200 dark:bg-slate-700' : 'bg-brand-500'}`}>
                {msg.role === 'user' ? (
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">You</span>
                ) : (
                  <Bot size={16} className="text-white" />
                )}
              </div>
              <div className={`max-w-[80%] rounded-xl p-3 ${msg.role === 'user' ? 'bg-brand-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'}`}>
                <p className="text-sm whitespace-pre-wrap leading-relaxed">{msg.content}</p>
              </div>
            </div>
          ))}

          {loading && <ThinkingIndicator />}
          {error && <ErrorBanner message={error} />}
        </div>

        <form onSubmit={handleSubmit} className="p-4 border-t border-slate-200 dark:border-slate-800">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask LifeOS AI anything..."
              className="input flex-1"
              disabled={loading}
              aria-label="Message"
            />
            <button type="submit" className="btn-primary shrink-0" disabled={loading || !input.trim()}>
              <Send size={18} />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
