import { useEffect, useState } from 'react';
import { Plus, CheckSquare, Pencil, Trash2, CheckCircle2, Circle, RotateCcw, AlertCircle, Calendar } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { formatDate, todayISO, getFriendlyError } from '@/lib/utils';
import { PageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import { Modal } from '@/components/Modal';
import { PriorityBadge } from '@/components/Badges';
import { PRIORITIES, type Task, type Goal, type Priority } from '@/types';

type Filter = 'all' | 'today' | 'upcoming' | 'completed';

export function TasksPage() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<Filter>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Task | null>(null);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [goalId, setGoalId] = useState('');
  const [priority, setPriority] = useState<Priority>('Medium');
  const [dueDate, setDueDate] = useState('');

  useEffect(() => { loadData(); }, [user]);

  async function loadData() {
    if (!user) return;
    const [tasksRes, goalsRes] = await Promise.all([
      supabase.from('tasks').select('*, goals(title)').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('goals').select('*').eq('user_id', user.id).eq('status', 'active').order('title'),
    ]);
    setTasks((tasksRes.data as Task[]) || []);
    setGoals((goalsRes.data as Goal[]) || []);
    setLoading(false);
  }

  const today = todayISO();
  const filtered = tasks.filter((t) => {
    switch (filter) {
      case 'today': return t.due_date === today && t.status === 'pending';
      case 'upcoming': return t.due_date && t.due_date > today && t.status === 'pending';
      case 'completed': return t.status === 'completed';
      default: return true;
    }
  });

  const filters: { value: Filter; label: string; count: number }[] = [
    { value: 'all', label: 'All', count: tasks.length },
    { value: 'today', label: 'Today', count: tasks.filter((t) => t.due_date === today && t.status === 'pending').length },
    { value: 'upcoming', label: 'Upcoming', count: tasks.filter((t) => t.due_date && t.due_date > today && t.status === 'pending').length },
    { value: 'completed', label: 'Completed', count: tasks.filter((t) => t.status === 'completed').length },
  ];

  function openCreate() {
    setEditingTask(null);
    setTitle(''); setDescription(''); setGoalId(''); setPriority('Medium'); setDueDate('');
    setFormError('');
    setModalOpen(true);
  }

  function openEdit(task: Task) {
    setEditingTask(task);
    setTitle(task.title); setDescription(task.description || ''); setGoalId(task.goal_id || ''); setPriority(task.priority); setDueDate(task.due_date || '');
    setFormError('');
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError('');
    if (title.trim().length < 2) { setFormError('Task title cannot be empty.'); return; }

    setSaving(true);
    const payload = { title: title.trim(), description: description.trim(), goal_id: goalId || null, priority, due_date: dueDate || null };
    if (editingTask) {
      const { error } = await supabase.from('tasks').update(payload).eq('id', editingTask.id);
      if (error) { setFormError(getFriendlyError(error)); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('tasks').insert(payload);
      if (error) { setFormError(getFriendlyError(error)); setSaving(false); return; }
    }
    setSaving(false);
    setModalOpen(false);
    loadData();
  }

  async function toggleComplete(task: Task) {
    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    await supabase.from('tasks').update({ status: newStatus }).eq('id', task.id);
    loadData();
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await supabase.from('tasks').delete().eq('id', deleteTarget.id);
    setDeleteTarget(null);
    loadData();
  }

  if (loading) return <PageLoader />;

  return (
    <div className="space-y-5 max-w-4xl mx-auto animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Tasks</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">Manage your tasks and to-dos.</p>
        </div>
        <button onClick={openCreate} className="btn-primary"><Plus size={18} /> Add Task</button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filter === f.value ? 'bg-brand-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
          >
            {f.label} <span className={`ml-1 text-xs ${filter === f.value ? 'text-brand-100' : 'text-slate-400'}`}>{f.count}</span>
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={CheckSquare}
            title={filter === 'completed' ? 'No completed tasks yet.' : 'Nothing scheduled yet.'}
            description={filter === 'completed' ? 'Complete tasks to see them here.' : 'Create your first task to start organizing your day.'}
            action={<button onClick={openCreate} className="btn-primary"><Plus size={18} /> Add Task</button>}
          />
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((task) => (
            <div key={task.id} className={`card p-4 flex items-start gap-3 ${task.status === 'completed' ? 'opacity-60' : ''}`}>
              <button onClick={() => toggleComplete(task)} className="mt-0.5 shrink-0" aria-label={task.status === 'completed' ? 'Reopen task' : 'Complete task'}>
                {task.status === 'completed' ? <CheckCircle2 size={20} className="text-emerald-500" /> : <Circle size={20} className="text-slate-300 dark:text-slate-600 hover:text-brand-500 transition-colors" />}
              </button>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <h3 className={`font-medium text-slate-900 dark:text-white ${task.status === 'completed' ? 'line-through' : ''}`}>{task.title}</h3>
                  <PriorityBadge priority={task.priority} />
                </div>
                {task.description && <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">{task.description}</p>}
                <div className="flex flex-wrap items-center gap-2 mt-2">
                  {task.goals?.title && <span className="badge bg-brand-50 dark:bg-brand-950/30 text-brand-700 dark:text-brand-400">{task.goals.title}</span>}
                  {task.due_date && (
                    <span className="badge bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      <Calendar size={12} /> {formatDate(task.due_date)}
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {task.status === 'completed' && (
                  <button onClick={() => toggleComplete(task)} className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Reopen task">
                    <RotateCcw size={16} />
                  </button>
                )}
                <button onClick={() => openEdit(task)} className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Edit task">
                  <Pencil size={16} />
                </button>
                <button onClick={() => setDeleteTarget(task)} className="p-1.5 rounded-lg text-slate-400 hover:bg-red-50 dark:hover:bg-red-950/30 hover:text-red-500" aria-label="Delete task">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create/Edit modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingTask ? 'Edit Task' : 'New Task'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 text-sm">
              <AlertCircle size={16} className="shrink-0 mt-0.5" /> {formError}
            </div>
          )}
          <div>
            <label htmlFor="task-title" className="label">Title *</label>
            <input id="task-title" type="text" value={title} onChange={(e) => setTitle(e.target.value)} className="input" placeholder="e.g., Complete React lesson 3" required autoFocus />
          </div>
          <div>
            <label htmlFor="task-desc" className="label">Description</label>
            <textarea id="task-desc" value={description} onChange={(e) => setDescription(e.target.value)} className="input min-h-[70px] resize-none" placeholder="Add details..." />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="task-goal" className="label">Assign to Goal</label>
              <select id="task-goal" value={goalId} onChange={(e) => setGoalId(e.target.value)} className="input">
                <option value="">No goal</option>
                {goals.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="task-pri" className="label">Priority</label>
              <select id="task-pri" value={priority} onChange={(e) => setPriority(e.target.value as Priority)} className="input">
                {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label htmlFor="task-date" className="label">Due Date</label>
            <input id="task-date" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="input" min={todayISO()} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
            <button type="submit" className="btn-primary" disabled={saving}>{saving ? 'Saving...' : editingTask ? 'Save Changes' : 'Create Task'}</button>
          </div>
        </form>
      </Modal>

      {/* Delete confirmation */}
      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete Task?">
        <div className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Are you sure you want to delete "<span className="font-medium text-slate-900 dark:text-white">{deleteTarget?.title}</span>"? This action cannot be undone.
          </p>
          <div className="flex justify-end gap-2">
            <button onClick={() => setDeleteTarget(null)} className="btn-secondary">Cancel</button>
            <button onClick={handleDelete} className="btn-danger"><Trash2 size={16} /> Delete</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
