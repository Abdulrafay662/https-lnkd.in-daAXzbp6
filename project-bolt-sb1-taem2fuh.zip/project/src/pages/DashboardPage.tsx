import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Target, CheckSquare, Repeat, TrendingUp, Bot, Plus,
  Clock, AlertCircle, Flame, ArrowRight, Sparkles,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { getGreeting, todayISO, formatDate } from '@/lib/utils';
import { PageLoader } from '@/components/Loading';
import { PriorityBadge } from '@/components/Badges';
import { generateNotifications } from '@/lib/notifications';
import type { Goal, Task, Habit, HabitLog } from '@/types';

export function DashboardPage() {
  const { user, profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [habitLogs, setHabitLogs] = useState<Map<string, string[]>>(new Map());
  const [aiFocus, setAiFocus] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    loadData();
    loadAiFocus();
  }, [user]);

  async function loadData() {
    if (!user) return;
    const [goalsRes, tasksRes, habitsRes, logsRes] = await Promise.all([
      supabase.from('goals').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('tasks').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('habits').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('habit_logs').select('*').eq('user_id', user.id).order('completed_date', { ascending: false }),
    ]);
    setGoals((goalsRes.data as Goal[]) || []);
    setTasks((tasksRes.data as Task[]) || []);
    setHabits((habitsRes.data as Habit[]) || []);
    const logs = (logsRes.data as HabitLog[]) || [];
    const logMap = new Map<string, string[]>();
    logs.forEach((l) => {
      const arr = logMap.get(l.habit_id) || [];
      arr.push(l.completed_date);
      logMap.set(l.habit_id, arr);
    });
    setHabitLogs(logMap);
    setLoading(false);
  }

  async function loadAiFocus() {
    if (!user) return;
    setAiLoading(true);
    try {
      const [goalsRes, tasksRes, habitsRes, logsRes] = await Promise.all([
        supabase.from('goals').select('title, status, category').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('tasks').select('title, status, priority').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('habits').select('id, name, frequency').eq('user_id', user.id),
        supabase.from('habit_logs').select('habit_id, completed_date').eq('user_id', user.id),
      ]);
      const goals = goalsRes.data || [];
      const tasks = tasksRes.data || [];
      const habits = habitsRes.data || [];
      const logs = logsRes.data || [];
      const habitData = habits.map((h: { id: string; name: string; frequency: string }) => ({
        name: h.name,
        frequency: h.frequency,
        logs: logs.filter((l: { habit_id: string }) => l.habit_id === h.id).map((l: { completed_date: string }) => l.completed_date),
      }));

      const token = (await supabase.auth.getSession()).data.session?.access_token;
      if (!token) return;
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-service`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
        },
        body: JSON.stringify({
          action: 'assistant',
          history: [{ role: 'user', content: 'What should I focus on today? Give me a brief, 2-3 sentence answer based on my actual data.' }],
          context: { goals, tasks, habits: habitData },
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.content) setAiFocus(data.content);
      }
    } catch {
      // Silent fail — AI focus is optional
    } finally {
      setAiLoading(false);
    }
  }

  if (loading) return <PageLoader />;

  const today = todayISO();
  const todayTasks = tasks.filter((t) => t.due_date === today && t.status === 'pending');
  const completedTasks = tasks.filter((t) => t.status === 'completed');
  const activeGoals = goals.filter((g) => g.status === 'active');
  const completedGoals = goals.filter((g) => g.status === 'completed');
  const goalsNeedingAttention = activeGoals.filter((g) => {
    if (!g.target_date) return false;
    const days = (new Date(g.target_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
    return days <= 7 && days >= 0;
  });
  const topPriority = todayTasks.sort((a, b) => {
    const order = { High: 0, Medium: 1, Low: 2 };
    return order[a.priority] - order[b.priority];
  })[0];

  // Streak calculation
  let maxStreak = 0;
  habits.forEach((h) => {
    const logs = habitLogs.get(h.id) || [];
    let streak = 0;
    let date = new Date();
    while (true) {
      const dateStr = date.toISOString().split('T')[0];
      if (logs.includes(dateStr)) {
        streak++;
        date.setDate(date.getDate() - 1);
      } else {
        break;
      }
    }
    maxStreak = Math.max(maxStreak, streak);
  });

  const completionRate = tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0;

  const stats = [
    { label: "Today's Tasks", value: todayTasks.length, icon: CheckSquare, color: 'text-brand-500', bg: 'bg-brand-50 dark:bg-brand-950/30' },
    { label: 'Completed Tasks', value: completedTasks.length, icon: CheckSquare, color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-950/30' },
    { label: 'Active Goals', value: activeGoals.length, icon: Target, color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-950/30' },
    { label: 'Completed Goals', value: completedGoals.length, icon: Target, color: 'text-purple-500', bg: 'bg-purple-50 dark:bg-purple-950/30' },
    { label: 'Active Habits', value: habits.length, icon: Repeat, color: 'text-sky-500', bg: 'bg-sky-50 dark:bg-sky-950/30' },
    { label: 'Habit Streak', value: `${maxStreak} days`, icon: Flame, color: 'text-orange-500', bg: 'bg-orange-50 dark:bg-orange-950/30' },
  ];

  const quickActions = [
    { label: 'Add Goal', icon: Target, to: '/dashboard/goals' },
    { label: 'Add Task', icon: CheckSquare, to: '/dashboard/tasks' },
    { label: 'Add Habit', icon: Repeat, to: '/dashboard/habits' },
    { label: 'Ask AI', icon: Bot, to: '/dashboard/assistant' },
  ];

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-fade-in">
      {/* Greeting */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
          {getGreeting()}, {profile?.full_name || 'there'}!
        </h1>
        <p className="text-slate-500 dark:text-slate-400 mt-1">Here's what matters today.</p>
      </div>

      {/* AI Focus */}
      <div className="card p-5 bg-gradient-to-br from-brand-50 to-slate-50 dark:from-slate-900 dark:to-slate-950 border-brand-100 dark:border-slate-800">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-500 flex items-center justify-center shrink-0">
            <Sparkles size={20} className="text-white" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-slate-900 dark:text-white mb-1">Today's AI Focus</p>
            {aiLoading ? (
              <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                <span className="typing-dot text-brand-400" />
                <span className="typing-dot text-brand-400" />
                <span className="typing-dot text-brand-400" />
                <span className="ml-1">LifeOS AI is thinking...</span>
              </div>
            ) : aiFocus ? (
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{aiFocus}</p>
            ) : (
              <p className="text-sm text-slate-500 dark:text-slate-400">Add goals and tasks to get a personalized AI focus recommendation.</p>
            )}
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className="card p-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg ${stat.bg} flex items-center justify-center shrink-0`}>
                  <Icon size={18} className={stat.color} />
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{stat.label}</p>
                  <p className="text-lg font-bold text-slate-900 dark:text-white">{stat.value}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Top priority */}
      {topPriority && (
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-3">
            <AlertCircle size={18} className="text-brand-500" />
            <h3 className="font-semibold text-slate-900 dark:text-white">Top Priority Today</h3>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-slate-900 dark:text-white">{topPriority.title}</p>
              {topPriority.due_date && <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Due {formatDate(topPriority.due_date)}</p>}
            </div>
            <PriorityBadge priority={topPriority.priority} />
          </div>
        </div>
      )}

      {/* Progress summary */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp size={18} className="text-brand-500" />
          <h3 className="font-semibold text-slate-900 dark:text-white">Progress Summary</h3>
        </div>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-600 dark:text-slate-400">Task Completion Rate</span>
              <span className="font-medium text-slate-900 dark:text-white">{completionRate}%</span>
            </div>
            <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div className="h-full rounded-full bg-brand-500 transition-all duration-500" style={{ width: `${completionRate}%` }} />
            </div>
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-600 dark:text-slate-400">Goal Completion</span>
              <span className="font-medium text-slate-900 dark:text-white">{completedGoals.length}/{goals.length}</span>
            </div>
            <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div className="h-full rounded-full bg-emerald-500 transition-all duration-500" style={{ width: `${goals.length > 0 ? (completedGoals.length / goals.length) * 100 : 0}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* Goals needing attention */}
      {goalsNeedingAttention.length > 0 && (
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-3">
            <Clock size={18} className="text-amber-500" />
            <h3 className="font-semibold text-slate-900 dark:text-white">Goals Needing Attention</h3>
          </div>
          <div className="space-y-2">
            {goalsNeedingAttention.map((g) => (
              <Link key={g.id} to="/dashboard/goals" className="flex items-center justify-between p-3 rounded-lg bg-amber-50 dark:bg-amber-950/20 hover:bg-amber-100 dark:hover:bg-amber-950/40 transition-colors">
                <span className="font-medium text-slate-900 dark:text-white text-sm">{g.title}</span>
                <span className="text-xs text-amber-600 dark:text-amber-400">Due {formatDate(g.target_date)}</span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Today's tasks */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <CheckSquare size={18} className="text-brand-500" />
            <h3 className="font-semibold text-slate-900 dark:text-white">Today's Tasks</h3>
          </div>
          <Link to="/dashboard/tasks" className="text-xs text-brand-600 dark:text-brand-400 hover:underline flex items-center gap-1">
            View all <ArrowRight size={12} />
          </Link>
        </div>
        {todayTasks.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400 py-4 text-center">No tasks scheduled for today.</p>
        ) : (
          <div className="space-y-2">
            {todayTasks.slice(0, 5).map((t) => (
              <div key={t.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                <div className="w-2 h-2 rounded-full bg-brand-500 shrink-0" />
                <span className="text-sm text-slate-700 dark:text-slate-300 flex-1">{t.title}</span>
                <PriorityBadge priority={t.priority} />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div>
        <h3 className="font-semibold text-slate-900 dark:text-white mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {quickActions.map((action, i) => {
            const Icon = action.icon;
            return (
              <Link key={i} to={action.to} className="card p-4 flex flex-col items-center gap-2 hover:shadow-md hover:border-brand-200 dark:hover:border-brand-800 transition-all group">
                <div className="w-10 h-10 rounded-lg bg-brand-50 dark:bg-brand-950/50 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Icon size={20} className="text-brand-500" />
                </div>
                <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{action.label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
