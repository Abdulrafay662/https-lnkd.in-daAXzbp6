import { useEffect, useState } from 'react';
import { Plus, Repeat, Pencil, Trash2, CheckCircle2, Flame, AlertCircle, Calendar } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { todayISO, getFriendlyError } from '@/lib/utils';
import { PageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import { Modal } from '@/components/Modal';
import { HABIT_FREQUENCIES, type Habit, type HabitLog, type HabitFrequency } from '@/types';

export function HabitsPage() {
  const { user } = useAuth();
  const [habits, setHabits] = useState<Habit[]>([]);
  const [logs, setLogs] = useState<Map<string, string[]>>(new Map());
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Habit | null>(null);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [frequency, setFrequency] = useState<HabitFrequency>('Daily');

  useEffect(() => { loadData(); }, [user]);

  async function loadData() {
    if (!user) return;
    const [habitsRes, logsRes] = await Promise.all([
      supabase.from('habits').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('habit_logs').select('*').eq('user_id', user.id).order('completed_date', { ascending: false }),
    ]);
    setHabits((habitsRes.data as Habit[]) || []);
    const logList = (logsRes.data as HabitLog[]) || [];
    const logMap = new Map<string, string[]>();
    logList.forEach((l) => {
      const arr = logMap.get(l.habit_id) || [];
      arr.push(l.completed_date);
      logMap.set(l.habit_id, arr);
    });
    setLogs(logMap);
    setLoading(false);
  }

  function getStreak(habitId: string): number {
    const habitLogs = logs.get(habitId) || [];
    let streak = 0;
    let date = new Date();
    while (true) {
      const dateStr = date.toISOString().split('T')[0];
      if (habitLogs.includes(dateStr)) {
        streak++;
        date.setDate(date.getDate() - 1);
      } else {
        break;
      }
    }
    return streak;
  }

  function isCompletedToday(habitId: string): boolean {
    return (logs.get(habitId) || []).includes(todayISO());
  }

  async function toggleToday(habit: Habit) {
    const today = todayISO();
    if (isCompletedToday(habit.id)) {
      await supabase.from('habit_logs').delete().eq('habit_id', habit.id).eq('completed_date', today);
    } else {
      await supabase.from('habit_logs').insert({ habit_id: habit.id, completed_date: today });
    }
    loadData();
  }

  function openCreate() {
    setEditingHabit(null);
    setName(''); setDescription(''); setFrequency('Daily');
    setFormError('');
    setModalOpen(true);
  }

  function openEdit(habit: Habit) {
    setEditingHabit(habit);
    setName(habit.name); setDescription(habit.description || ''); setFrequency(habit.frequency);
    setFormError('');
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError('');
    if (name.trim().length < 2) { setFormError('Habit name cannot be empty.'); return; }

    setSaving(true);
    const payload = { name: name.trim(), description: description.trim(), frequency };
    if (editingHabit) {
      const { error } = await supabase.from('habits').update(payload).eq('id', editingHabit.id);
      if (error) { setFormError(getFriendlyError(error)); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('habits').insert(payload);
      if (error) { setFormError(getFriendlyError(error)); setSaving(false); return; }
    }
    setSaving(false);
    setModalOpen(false);
    loadData();
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await supabase.from('habits').delete().eq('id', deleteTarget.id);
    setDeleteTarget(null);
    loadData();
  }

  if (loading) return <PageLoader />;

  return (
    <div className="space-y-5 max-w-4xl mx-auto animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Habits</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">Build consistent habits with daily tracking.</p>
        </div>
        <button onClick={openCreate} className="btn-primary"><Plus size={18} /> Add Habit</button>
      </div>

      {habits.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={Repeat}
            title="Build your first habit."
            description="Create a habit to start tracking your daily consistency."
            action={<button onClick={openCreate} className="btn-primary"><Plus size={18} /> Add Habit</button>}
          />
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {habits.map((habit) => {
            const streak = getStreak(habit.id);
            const completedToday = isCompletedToday(habit.id);
            const count = (logs.get(habit.id) || []).length;
            return (
              <div key={habit.id} className="card p-5">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h3 className="font-semibold text-slate-900 dark:text-white">{habit.name}</h3>
                  <span className="badge bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">{habit.frequency}</span>
                </div>
                {habit.description && <p className="text-sm text-slate-600 dark:text-slate-400 mb-3 line-clamp-2">{habit.description}</p>}
                <div className="flex items-center gap-4 mb-3">
                  <div className="flex items-center gap-1.5">
                    <Flame size={16} className="text-orange-500" />
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{streak} day streak</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 size={16} className="text-emerald-500" />
                    <span className="text-sm text-slate-600 dark:text-slate-400">{count} total</span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <button
                    onClick={() => toggleToday(habit)}
                    className={`btn text-xs px-3 py-1.5 ${completedToday ? 'bg-emerald-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                  >
                    <CheckCircle2 size={14} /> {completedToday ? 'Completed Today' : 'Mark Today'}
                  </button>
                  <button onClick={() => openEdit(habit)} className="btn-ghost text-xs px-3 py-1.5">
                    <Pencil size={14} /> Edit
                  </button>
                  <button onClick={() => setDeleteTarget(habit)} className="btn-ghost text-xs px-3 py-1.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30">
                    <Trash2 size={14} /> Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingHabit ? 'Edit Habit' : 'New Habit'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 text-sm">
              <AlertCircle size={16} className="shrink-0 mt-0.5" /> {formError}
            </div>
          )}
          <div>
            <label htmlFor="habit-name" className="label">Name *</label>
            <input id="habit-name" type="text" value={name} onChange={(e) => setName(e.target.value)} className="input" placeholder="e.g., Read 30 minutes" required autoFocus />
          </div>
          <div>
            <label htmlFor="habit-desc" className="label">Description</label>
            <textarea id="habit-desc" value={description} onChange={(e) => setDescription(e.target.value)} className="input min-h-[70px] resize-none" placeholder="Describe your habit..." />
          </div>
          <div>
            <label htmlFor="habit-freq" className="label">Frequency</label>
            <select id="habit-freq" value={frequency} onChange={(e) => setFrequency(e.target.value as HabitFrequency)} className="input">
              {HABIT_FREQUENCIES.map((f) => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
            <button type="submit" className="btn-primary" disabled={saving}>{saving ? 'Saving...' : editingHabit ? 'Save Changes' : 'Create Habit'}</button>
          </div>
        </form>
      </Modal>

      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete Habit?">
        <div className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Are you sure you want to delete "<span className="font-medium text-slate-900 dark:text-white">{deleteTarget?.name}</span>"? This will also delete all completion logs. This action cannot be undone.
          </p>
          <div className="flex justify-end gap-2">
            <button onClick={() => setDeleteTarget(null)} className="btn-secondary">Cancel</button>
            <button onClick={handleDelete} className="btn-danger"><Trash2 size={16} /> Delete</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
